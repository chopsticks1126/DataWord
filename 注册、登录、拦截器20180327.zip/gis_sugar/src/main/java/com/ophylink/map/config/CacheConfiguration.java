package com.ophylink.map.config;

import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Configuration;

/**
 * Created by MyPC on 2017/12/12.
 */
@Configuration
@EnableCaching
public class CacheConfiguration {
}
