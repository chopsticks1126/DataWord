package com.ophylink.map.web;

import com.ophylink.map.entity.cable;
import com.ophylink.map.entity.cablegroup;
import com.ophylink.map.service.cableServer;
import com.ophylink.map.service.cablegroupServer;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

/**
 * Created by MyPC on 2018/3/5.
 */
@RestController
@RequestMapping("/cable")
public class cableController {

    @Autowired
    private cableServer server;
    @Autowired
    private cablegroupServer groupserver;

    /***
     * 获取全部光缆
     * @return
     */
    @ApiOperation(value = "获取全部光缆",notes = "获取全部光缆信息")
    @RequestMapping(value = "/getall",method = RequestMethod.POST)
    public HashMap getAllCable() {
        HashMap retMap = new HashMap();
        try{
            retMap.put("cables",server.getAllCable());
            retMap.put("msg","get cable success");
            retMap.put("code",1);
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","get cable fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
        }
        return  retMap;
    }

    /**
     *  根据光缆名称获取光缆
     * @param cableName
     * @return
     */
    @ApiOperation(value = "获取一条光缆",notes = "获取一条光缆的信息")
    @ApiImplicitParam(value = "cableName",name = "光缆名称",required = true,dataType = "String")
    @RequestMapping(value = "/getcablebycablename",method = RequestMethod.POST)
    public HashMap getCableByCableName(String cableName){

        HashMap retMap = new HashMap();
        try {
            retMap.put("cable",server.getCableByCableName(cableName));
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 添加光缆
     * @param groupid
     * @param cableName
     * @param cableDesc
     * @param extendFieldString
     * @param cableNumber
     * @param cableCode
     * @param reservedCode
     * @param distance
     * @param coreNumber
     * @param startPoint
     * @param endPoint
     * @param manufacturer
     * @param item
     * @param cableParam
     * @return
     */
    @ApiOperation(value = "添加一个光缆",notes = "添加一个光缆信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name="groupid",value = "父组id",required = true,dataType = "long"),
            @ApiImplicitParam(name="cableName",value = "光缆的名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="cableDesc",value = "光缆的显示名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="extendFieldString",value = "光缆父组的名称",required = true,dataType = "string"),
            @ApiImplicitParam(name="cableNumber",value = "光缆序号",required = true,dataType = "int"),
            @ApiImplicitParam(name="cableCode",value = "光缆编码",required = true,dataType = "String"),
            @ApiImplicitParam(name="reservedCode",value = "预留码",required = true,dataType = "String"),
            @ApiImplicitParam(name="distance",value = "距离",required = true,dataType = "float"),
            @ApiImplicitParam(name="coreNumber",value = "纤芯数量",required = true,dataType = "int"),
            @ApiImplicitParam(name="startPoint",value = "始端",required = true,dataType = "String"),
            @ApiImplicitParam(name="endPoint",value = "终端",required = true,dataType = "String"),
            @ApiImplicitParam(name="manufacturer",value = "厂商",required = true,dataType = "String"),
            @ApiImplicitParam(name="item",value = "所属工程",required = true,dataType = "String"),
            @ApiImplicitParam(name="cableParam",value = "备注",required = true,dataType = "String")

    })
//    @RequestMapping(value = "/addcable/{groupid}/{cableName}/{cableDesc}/{extendFieldString}/{cableNumber}" +
//            "/{cableCode}/{reservedCode}/{distance}/{coreNumber}/{startPoint}/{endPoint}/{manufacturer}/{item}/{cableParam}",method = RequestMethod.GET)

    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public HashMap addCable(
            long groupid,
            String cableName,
            String cableDesc,
            String extendFieldString,
            int cableNumber,
            String cableCode,
            String reservedCode,
            float distance,
            int coreNumber,
            String startPoint,
            String endPoint,
            String manufacturer,
            String item,
            String cableParam
    ){
        HashMap retMap = new HashMap();
        try {
            cable cable = new cable();
            cable.setCableName(cableName);
            cable.setCableDesc(cableDesc);
            cable.setGroupid(groupid);
            cable.setExtendFieldString(extendFieldString);//占用，存光缆组名称
            cable.setCableNumber(cableNumber);
            cable.setCableCode(cableCode);
            cable.setReservedCode(reservedCode);
            cable.setDistance(distance);
            cable.setCoreNumber(coreNumber);
            cable.setStartPoint(startPoint);
            cable.setEndPoint(endPoint);
            cable.setManufacturer(manufacturer);
            cable.setItem(item);
            cable.setCableParam(cableParam);
            server.addCable(cable);
            retMap.put("msg","add cable success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","add cable fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 修改光缆
     * @param id
     * @param groupid
     * @param cableDesc
     * @param extendFieldString
     * @param cableNumber
     * @param cableCode
     * @param reservedCode
     * @param distance
     * @param coreNumber
     * @param startPoint
     * @param endPoint
     * @param manufacturer
     * @param item
     * @param cableParam
     * @return
     */
    @ApiOperation(value = "修改一个光缆",notes = "修改一个光缆信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value = "id",required = true,dataType = "long"),
            @ApiImplicitParam(name="groupid",value = "父组id",required = true,dataType = "long"),
            @ApiImplicitParam(name="cableDesc",value = "光缆的显示名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="extendFieldString",value = "光缆父组的名称",required = true,dataType = "string"),
            @ApiImplicitParam(name="cableNumber",value = "光缆序号",required = true,dataType = "int"),
            @ApiImplicitParam(name="cableCode",value = "光缆编码",required = true,dataType = "String"),
            @ApiImplicitParam(name="reservedCode",value = "预留码",required = true,dataType = "String"),
            @ApiImplicitParam(name="distance",value = "距离",required = true,dataType = "float"),
            @ApiImplicitParam(name="coreNumber",value = "纤芯数量",required = true,dataType = "int"),
            @ApiImplicitParam(name="startPoint",value = "始端",required = true,dataType = "String"),
            @ApiImplicitParam(name="endPoint",value = "终端",required = true,dataType = "String"),
            @ApiImplicitParam(name="manufacturer",value = "厂商",required = true,dataType = "String"),
            @ApiImplicitParam(name="item",value = "所属工程",required = true,dataType = "String"),
            @ApiImplicitParam(name="cableParam",value = "备注",required = true,dataType = "String")
    })
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public HashMap updateGroup(
            long id,
            long groupid,
            String cableDesc,
            String extendFieldString,
            int cableNumber,
            String cableCode,
            String reservedCode,
            float distance,
            int coreNumber,
            String startPoint,
            String endPoint,
            String manufacturer,
            String item,
            String cableParam
    ){
        HashMap retMap = new HashMap();
        try {
            cable cable = new cable();
            cable.setId(id);
            cable.setCableDesc(cableDesc);
            cable.setGroupid(groupid);
            cable.setExtendFieldString(extendFieldString);//占用，存光缆组名称
            cable.setCableNumber(cableNumber);
            cable.setCableCode(cableCode);
            cable.setReservedCode(reservedCode);
            cable.setDistance(distance);
            cable.setCoreNumber(coreNumber);
            cable.setStartPoint(startPoint);
            cable.setEndPoint(endPoint);
            cable.setManufacturer(manufacturer);
            cable.setItem(item);
            cable.setCableParam(cableParam);
            server.updateCable(cable);
            retMap.put("msg","update cable success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","update cable fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 删除光缆
     * @param id
     * @return
     */

    @ApiOperation(value = "删除一个光缆",notes = "根据光缆id删除光缆")
    @ApiImplicitParam(name="id",value = "id",required = true,dataType = "int",paramType="path")
    @RequestMapping(value = "/del",method = RequestMethod.POST)
    public HashMap deleteCable(int id){
        HashMap retMap = new HashMap();
        try{
            server.deleteCable(id);
            retMap.put("msg","delete cable success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            retMap.put("msg","delete cable fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 根据选中的光缆组ID和光缆ID获取所有光缆
     * @return
     */
    @ApiOperation(value = "获取一条光缆",notes = "获取一条光缆的信息")
    @ApiImplicitParams({
        @ApiImplicitParam(value = "cableids",name = "光缆Ids",required = true,dataType = "Long[]"),
        @ApiImplicitParam(value = "groupids",name = "光缆组Ids",required = true,dataType = "Long[]")
    })
    @RequestMapping(value = "/getcablebyids",method = RequestMethod.POST)
    public HashMap getCableByIds(Long[] cableids,Long[] groupids){
        HashMap retMap = new HashMap();
        try {
            //得到所有的光缆组ID
            List<Long> groupidlist = new ArrayList<>(Arrays.asList(groupids));
            List<Long> groupids1 = getAllGroupIds(groupidlist,groupidlist);
            //得到所有光缆，根据光缆组ID及光缆ID
            HashMap<String,List<Long>> map = new HashMap();
            map.put("cableids", Arrays.asList(cableids));
            map.put("groupids", groupids1);
            retMap.put("cables",server.getCableByIds(map));
            retMap.put("msg","success");
            retMap.put("code",1);
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 级联查询，根据光缆组ID得到所有光缆组
     * @param ids
     * @return
     */
    public List<Long> getAllGroupIds(List<Long> groupids,List<Long> ids) {
        try {
            List<cablegroup> groups = groupserver.getGroupByGroupPIds(ids);
            Iterator it = groups.iterator();
            while (it.hasNext()) {
                cablegroup group = (cablegroup) it.next();
                if (!groupids.contains(group.getId())){
                    groupids.add(group.getId());
//                    System.out.println(group.getId() + "---------------");
                }
                List<Long> list = new ArrayList<>();
                list.add(group.getId());
                getAllGroupIds(groupids,list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return groupids;
    }
}
