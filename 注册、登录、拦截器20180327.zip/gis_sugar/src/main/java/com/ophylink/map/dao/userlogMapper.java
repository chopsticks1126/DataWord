package com.ophylink.map.dao;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface userlogMapper {
}
