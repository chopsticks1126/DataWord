package com.ophylink.map.config;

import com.ophylink.map.Interceptor.LoginInterceptor;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
public class WebLoginSecurityConfig extends WebMvcConfigurerAdapter  {
    private ApplicationContext applicationContext;

    @Bean
    public LoginInterceptor getSecurityInterceptor() {
        return new LoginInterceptor();
    }
    public void addInterceptors(InterceptorRegistry registry) {
        InterceptorRegistration addInterceptor = registry.addInterceptor(getSecurityInterceptor());//注册拦截器
        // 排除配置
        addInterceptor.excludePathPatterns("/error");
        addInterceptor.excludePathPatterns("/UserController/login**");
        addInterceptor.excludePathPatterns("/UserController/signUp**");
      //   拦截配置
        addInterceptor.addPathPatterns("/UserController/**");
    }

}
