package com.ophylink.map.dao;

import com.ophylink.map.entity.userinfo;

import java.util.List;
import java.util.Map;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface userinfoMapper {

    public List getall();

    //GIS 登录
    /**
     * 添加一个用户
     * @return
     * @throws Exception
     */
    public boolean signUp(userinfo user) throws Exception;
    /**
     * 用户登录
     * @return
     * @throws Exception
     */
    public  userinfo selectByLogin(String name) throws Exception;

    /**
     * 查询所有的用户
     * @return
     * @throws Exception
     */
    public List<userinfo> selectAllUser() throws  Exception;

    /**
     * 查询所有用户的数量
     * @return
     * @throws Exception
     */
    public int selectCont() throws Exception;

    /**
     * 分页查询
     * @param map
     * @return
     * @throws Exception
     */
    public List<userinfo> selectBypage(Map<String,Integer> map) throws Exception;

    /**
     * 校验用户名是否重复
     * @param map
     * @return
     * @throws Exception
     */
    public List<userinfo> checkName(Map<String,String> map)throws Exception;
}
