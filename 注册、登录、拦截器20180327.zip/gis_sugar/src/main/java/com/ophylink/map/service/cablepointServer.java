package com.ophylink.map.service;


import com.ophylink.map.dao.cablepointMapper;
import com.ophylink.map.entity.cablepoint;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
@Service
public class cablepointServer {

    @Autowired
    private cablepointMapper mapper;

    /***
     *获取全部光缆节点的信息
     * @return
     * @throws Exception
     */
    public List<cablepoint> getAllPoint() throws Exception{
        return mapper.getAllPoint();
    }

    /**
     * 获取一个光缆节点
     * @param pointName
     * @return
     * @throws Exception
     */
    public cablepoint getPointByPointName(String pointName) throws Exception{
        return mapper.getPointByPointName(pointName);
    }

    /**
     * 根据光缆ID获取它的所有节点
     * @param cableId
     * @return
     * @throws Exception
     */
    public List<cablepoint> getPointsByCableId(long cableId) throws Exception{
        return mapper.getPointsByCableId(cableId);
    }

    /**
     * 添加一个光缆节点
     * @param point
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean addPoint(cablepoint point) throws Exception{
        return mapper.addPoint(point);
    }

    /**
     * 更新一个光缆节点
     * @param point
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean updatePoint(cablepoint point) throws Exception{
        return mapper.updatePoint(point);
    }

    /***
     * 删除一个光缆节点
     * @param id
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean deletePoint(int id) throws Exception{
        return mapper.deletePoint(id);
    }

    /**
     * 获取所有光缆节点及前节点的经纬度
     * @return
     * @throws Exception
     */
    public List<HashMap> getPointsByPointId() throws Exception{
        return mapper.getPointsByPointId();
    }

    /**
     * 根据光缆ID获取光缆节点
     * @param Ids
     * @return
     * @throws Exception
     */
    public List<cablepoint> getCableByIdsAndCableIds(HashMap<String,List<Long>> Ids) throws Exception{
        return mapper.getCableByIdsAndCableIds(Ids);
    }
}
