package com.ophylink.map.service;

import com.ophylink.map.dao.cableMapper;
import com.ophylink.map.entity.cable;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
@Service
public class cableServer {

    @Autowired
    private cableMapper mapper;

    /***
     *获取全部光缆的信息
     * @return
     * @throws Exception
     */
    public List<cable> getAllCable() throws Exception{
        return mapper.getAllCable();
    }

    /**
     * 获取一个光缆
     * @param cableName
     * @return
     * @throws Exception
     */
    public cable getCableByCableName(String cableName) throws Exception{
        return mapper.getCableByCableName(cableName);
    }

    /**
     * 添加一个光缆
     * @param cable
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean addCable(cable cable) throws Exception{
        return mapper.addCable(cable);
    }

    /**
     * 更新一个光缆
     * @param cable
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean updateCable(cable cable) throws Exception{
        return mapper.updateCable(cable);
    }

    /***
     * 删除一个光缆
     * @param id
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean deleteCable(int id) throws Exception{
        return mapper.deleteCable(id);
    }

    /**
     * 根据光缆组ID查询光缆组下所有光缆
     * @param groupids
     * @return
     * @throws Exception
     */
    public List<cable> getCableByPIds(List<Long> groupids) throws Exception{
        return mapper.getCableByPIds(groupids);
    }

    /**
     * 根据光缆组ID和光缆ID查询所有光缆
     * @param map
     * @return
     * @throws Exception
     */
    public List<cable> getCableByIds(HashMap<String,List<Long>> map) throws Exception{
        return mapper.getCableByIds(map);
    }
}
