package com.ophylink.map.service;

import com.ophylink.map.dao.permissionsMapper;
import com.ophylink.map.entity.permissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;


/**
 * Created by MyPC on 2017/12/5.
 */
@Service
public class PermissionService {

    @Autowired
    private permissionsMapper permissionsMapper;

    /**
     * 查询所有的权限数据
     * @return
     * @throws Exception
     */
    public List<permissions> selAllPs() throws Exception{
        return permissionsMapper.selAllPs();
    }


}
