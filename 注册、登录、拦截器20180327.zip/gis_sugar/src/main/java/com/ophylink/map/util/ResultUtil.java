package com.ophylink.map.util;


import java.util.HashMap;
import java.util.Map;

public class ResultUtil {
    /**
     * 操作成功
     * @param obj
     * @return
     */
    public static Map success(Object obj){
        Map mapobj = new HashMap();
//        Result  result = new Result();
//        result.setCode(0);
//        result.setMsg("成功");
//        result.setData(obj);
        mapobj.put("message","成功");
     //   mapobj.put("result",obj);
        mapobj.put("dataInfos",obj);
        return mapobj;
    }



    public static Map fail(){
        Map mapobj = new HashMap();
//        Result  result = new Result();
//        result.setCode(1);
//        result.setMsg("失败");
//        result.setData(null);
        mapobj.put("message","失败");
        mapobj.put("result",null);
        return mapobj;
    }
    /**
     * 操作成功的提示语
     * @return
     */
    public static Map successMsg(){
        Map mapobj = new HashMap();
        mapobj.put("code","0");
        mapobj.put("message","success");
        return mapobj;
    }

    /**
     * 操作失败的提示语
     * @return
     */
    public static Map failMsg(){
        Map mapobj = new HashMap();
        mapobj.put("code","1");
        mapobj.put("message","fail");
        return mapobj;
    }

}
