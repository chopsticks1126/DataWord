package com.ophylink.map.dao;

import com.ophylink.map.entity.cablealarm;
import com.sun.xml.internal.xsom.impl.scd.Iterators;

import java.util.HashMap;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface cablealarmMapper {

    /**
     * 获取全部光缆告警的信息
     * @return
     * @throws Exception
     */
    public List<cablealarm> getAllAlarm() throws Exception;

    /**
     * 根据光缆ID获取光缆所有告警信息
     * @param cableids
     * @return
     * @throws Exception
     */
    public List<cablealarm> getAlarmsByCableId(List<Long> cableids) throws Exception;

    /**
     * 根据光缆组ID获取光缆组下所有光缆的告警信息
     * @param groupids
     * @return
     * @throws Exception
     */
    public List<cablealarm> getAlarmsByGroupId(List<Long> groupids) throws Exception;

    /**
     * 根据光缆组ID和光缆ID获取光缆组下所有光缆和光缆的的告警信息
     * @param ids
     * @return
     * @throws Exception
     */
    public List<cablealarm> getAlarmsByIds(HashMap<String,List<Long>> ids) throws Exception;

    /**
     * 根据告警ID删除一条告警
     * @param id
     * @return
     * @throws Exception
     */
    public boolean deleteAlarm(int id) throws Exception;

    /**
     * 根据告警ID删除多条告警
     * @param ids
     * @return
     * @throws Exception
     */
    public boolean deleteAlarms(List<Long> ids) throws Exception;
}
