package com.ophylink.map.dao;

import com.ophylink.map.entity.cablegroup;

import java.util.Arrays;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface cablegroupMapper {
    /***
     *获取全部光缆组的信息
     * @return
     * @throws Exception
     */
    public List<cablegroup> getAllGroup() throws Exception;

    /**
     * 添加一个光缆组
     * @param group
     * @return
     * @throws Exception
     */
    public boolean addGroup(cablegroup group) throws Exception;

    /**
     * 更新一个光缆组
     * @param group
     * @return
     * @throws Exception
     */
    public boolean updateGroup(cablegroup group) throws Exception;

    /***
     * 删除一个光缆组
     * @param id
     * @return
     * @throws Exception
     */
    public boolean deleteGroup(int id) throws Exception;

    /**
     * 获取一个光缆组
     * @param groupname
     * @return
     * @throws Exception
     */
    public cablegroup getGroupByGroupName(String groupname) throws Exception;

    /**
     * 根据选中的光缆组父组ID过去光缆组
     * @param ids
     * @return
     * @throws Exception
     */
    public List<cablegroup> getGroupByGroupPIds(List<Long> ids) throws Exception;

    /**
     * 根据选中的光缆组ID过去光缆组
     * @param ids
     * @return
     * @throws Exception
     */
    public List<cablegroup> getGroupByGroupIds(List<Long> ids) throws Exception;
}
