package com.ophylink.map.Interceptor;

import com.ophylink.map.entity.SessionData;
import com.ophylink.map.entity.userinfo;
import com.ophylink.map.web.userController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginInterceptor implements HandlerInterceptor {
    public static Logger logger= LoggerFactory.getLogger(LoginInterceptor.class);
    public static final  String SESSION_KEY = "userSessionName";
    private static final String requsetHeader ="x-requested-with";
    private static final String requsetIdentity ="XMLHttpRequest";
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object o) throws Exception {
        HttpSession session = request.getSession();
        userinfo userinfo = (userinfo) request.getSession().getAttribute(SESSION_KEY);
        if(userinfo!=null){
            String token = SessionData.getSessionIDMap().get(userinfo.getUsername());
            if(token!=null){
                logger.info("已经成功登录");
                return true;
            }else{
                redirectMethod(request, response);
                logger.info("没有登录");
                return false;
            }
        }else{
            redirectMethod(request, response);
            logger.info("没有登录咯");
            return false;
        }
    }

    /**
     * 区别不同的请求，区分重定向方法
     * @param request
     * @param response
     * @throws Exception
     */
    private  void redirectMethod(HttpServletRequest request, HttpServletResponse response) throws Exception{
        logger.info("当前页面"+request.getRequestURI());
        if(isRequst(request)){//ajax 请求
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("会话失效，请重新登录");
            response.flushBuffer();
        }else{
            String url = "/UserController/loginIndex";//重定向到登录页
            response.sendRedirect(url);
        }
    }
    /**
     * 判断请求是否是ajax请求
     * @param request
     * @return
     */
    private boolean isRequst(HttpServletRequest request){
        String ajaxHeader = request.getHeader(requsetHeader);
        boolean flag = false;
        if(ajaxHeader !=null &&!("").equals(ajaxHeader) && requsetIdentity.equals(ajaxHeader)){
            flag =true;
        }
        return flag;
    }
    @Override
    public void postHandle(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, ModelAndView modelAndView) throws Exception {

    }
    @Override
    public void afterCompletion(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, Object o, Exception e) throws Exception {

    }
}
