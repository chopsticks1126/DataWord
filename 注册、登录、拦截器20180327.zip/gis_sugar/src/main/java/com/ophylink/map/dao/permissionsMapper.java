package com.ophylink.map.dao;

import com.ophylink.map.entity.permissions;

import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface permissionsMapper {
    public List<permissions> selAllPs() throws Exception;
}
