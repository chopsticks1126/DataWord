package com.ophylink.map.service;

import com.ophylink.map.dao.cablegroupMapper;
import com.ophylink.map.entity.cablegroup;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
@Service
public class cablegroupServer {

    @Autowired
    private cablegroupMapper mapper;

    /***
     *获取全部光缆组的信息
     * @return
     * @throws Exception
     */
    public List<cablegroup> getAllGroup() throws Exception{
        return mapper.getAllGroup();
    }

    /**
     * 获取一个光缆组
     * @param groupname
     * @return
     * @throws Exception
     */
    public cablegroup getGroupByGroupName(String groupname) throws Exception{
        return mapper.getGroupByGroupName(groupname);
    }

    /**
     * 添加一个光缆组
     * @param group
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean addGroup(cablegroup group) throws Exception{
        return mapper.addGroup(group);
    }

    /**
     * 更新一个光缆组
     * @param group
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean updateGroup(cablegroup group) throws Exception{
        return mapper.updateGroup(group);
    }

    /***
     * 删除一个光缆组
     * @param id
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean deleteGroup(int id) throws Exception{
        return mapper.deleteGroup(id);
    }

    /**
     * 根据选中的光缆组父组ID过去光缆组
     * @param ids
     * @return
     * @throws Exception
     */
    public List<cablegroup> getGroupByGroupPIds(List<Long> ids) throws Exception{
        return mapper.getGroupByGroupPIds(ids);
    }

    /**
     * 根据选中的光缆组ID过去光缆组
     * @param ids
     * @return
     * @throws Exception
     */
    public List<cablegroup> getGroupByGroupIds(List<Long> ids) throws Exception{
        return mapper.getGroupByGroupIds(ids);
    }
}
