package com.ophylink.map.service;

import com.ophylink.map.dao.userinfoMapper;
import com.ophylink.map.entity.userinfo;
import com.ophylink.map.util.DesUtil;
import com.ophylink.map.util.ResultUtil;
import com.ophylink.map.web.userController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by MyPC on 2017/12/5.
 */
@Service
public class userService {
    public static Logger logger = LoggerFactory.getLogger(userService.class);

       @Autowired
        private userinfoMapper userMapper;



       public List getall() throws Exception{
           return userMapper.getall();
       }
//
//    /**
//     * 用户登录
//     * @param uname
//     * @param password
//     * @return
//     * @throws Exception
//     */
//    public mUser userLogin(String uname,String password) throws Exception{
//        mUser user = new mUser();
//        user.setUname(uname);
//        user.setPass(password);
//        return userMapper.userLogin(user);
//    }
//
//    /**
//     * 添加用户
//     * @param user
//     * @return
//     * @throws Exception
//     */
//    @Transactional
//    public boolean addUser(mUser user) throws Exception{
//       boolean flag=true;
//        if(user!=null){
//          flag = userMapper.addUser(user);
//       }else {
//            flag=false;
//        }
//       return flag;
//    }
//
//    public int isExist(String username) throws Exception
//    {
//        return userMapper.isExist(username);
//    }

    //GIS 登录注册

    /**
     * 注册
     * @param user
     * @return
     */
    public boolean signUp(userinfo user){
        boolean flag = false;
        try {
            flag = userMapper.signUp(user);
        } catch (Exception e){
            e.printStackTrace();
            flag= false;
        }
        return flag;
    }

    /**
     * 校验登录用户信息
     * @param name
     * @return
     */
    public userinfo selectByLogin(String name){
        userinfo user= null;
        try {
            user =userMapper.selectByLogin(name);
        } catch (Exception e){
            e.printStackTrace();
        }

        return user;
    }

    /**
     * 查询所有的用户
     * @return
     */
    public   Map selectAllUser(String page,String pageSize){
        if(page==null || ("").equals(page)){
            page ="1";
        }
        if(pageSize == null || ("").equals(pageSize)){
            pageSize ="10";
        }
        // List<User> users= null;
        Map map = new HashMap<>();
        List<userinfo> user = null;
        try {
            // users =userMapper.selectAllUser();
            int nums = userMapper.selectCont();//所有用户数量
            int totalPage =0;
            if(nums<10){
                 totalPage=1;
            }else{
                 totalPage =getTotalPage(nums,10);
            }

            Map<String,Integer> mapPage = new HashMap<String,Integer>();
//            String page ="1";
//            String pageSize ="10";
            int pageStart = (Integer.valueOf(page)-1)*(Integer.valueOf(pageSize));
            int pageEnd = Integer.valueOf(page)*(Integer.valueOf(pageSize));
            if(pageEnd>nums){
                pageEnd = nums;
            }
            mapPage.put("pageStart",pageStart);
            mapPage.put("pageEnd",pageEnd);
            System.out.println(mapPage);
            user = userMapper.selectBypage(mapPage);
            //将用户名解密
            List <userinfo> userNew = new ArrayList<>();
            userinfo u = new userinfo();
            if(user!=null && user.size()>0){
                for (int i = 0;i<user.size();i++){
                    u = user.get(i);
                    u.setUsername(DesUtil.decrypt(u.getUsername()));
                    userNew.add(u);
                }
            }
            logger.info("分页查询用户权限分配情况，当前页数："+page);
            map.put("userInfo",userNew);
            map.put("totalPage",String.valueOf(totalPage));
            map.put("page",page);
            map.put("nums",String.valueOf(nums));
        } catch (Exception e){
            e.printStackTrace();
        }
        return map;
    }

    /**
     * 取得总页数
     * @param nums
     * @param pageSize
     * @return
     */
    public int getTotalPage(int nums ,int pageSize){
        System.out.println(nums /pageSize);
        if (nums / pageSize == 0)
            return nums / pageSize;
        else
            return nums / pageSize + 1;
    }

    /**
     * 校验用户名是否重复
     * @param username
     * @return
     */
    public Map checkName(String username){
        Map<String,String> checkNameMap = new HashMap();
        try {
            checkNameMap.put("username",DesUtil.encrypt(username));
            List<userinfo> checkName = userMapper.checkName(checkNameMap);
            if(checkName!=null && checkName.size()>0){
                logger.info("校验用户名是否重复");
                return ResultUtil.failMsg();
            }else{
                return ResultUtil.successMsg();
            }
        }catch (Exception e){
            e.printStackTrace();
            return ResultUtil.failMsg();
        }
    }
}
