package com.ophylink.map.entity;

import java.sql.Timestamp;
import java.util.Objects;

/**
 * Created by MyPC on 2018/3/5.
 */
public class cable {
    private long id;
    private String cableName;
    private long groupid;
    private int cableNumber = 0;
    private String reservedCode="";
    private String cableCode="";
    private String manufacturer="";
    private float distance=0;
    private int coreNumber=0;
    private String cableDesc="";
    private String startPoint="";
    private String endPoint="";
    private String item="";
    private Timestamp createtime;
    private String cableParam="";
    private String extendFieldString="";
    private long extendFieldLong=0;
    private String extendFieldStringB="";
    private long extendFieldLongB=0;
    private String extendFieldStringC="";
    private long extendFieldLongC=0;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCableName() {
        return cableName;
    }

    public void setCableName(String cableName) {
        this.cableName = cableName;
    }

    public long getGroupid() {
        return groupid;
    }

    public void setGroupid(long groupid) {
        this.groupid = groupid;
    }

    public int getCableNumber() {
        return cableNumber;
    }

    public void setCableNumber(int cableNumber) {
        this.cableNumber = cableNumber;
    }

    public String getReservedCode() {
        return reservedCode;
    }

    public void setReservedCode(String reservedCode) {
        this.reservedCode = reservedCode;
    }

    public String getCableCode() {
        return cableCode;
    }

    public void setCableCode(String cableCode) {
        this.cableCode = cableCode;
    }

    public String getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(String manufacturer) {
        this.manufacturer = manufacturer;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public int getCoreNumber() {
        return coreNumber;
    }

    public void setCoreNumber(int coreNumber) {
        this.coreNumber = coreNumber;
    }

    public String getCableDesc() {
        return cableDesc;
    }

    public void setCableDesc(String cableDesc) {
        this.cableDesc = cableDesc;
    }

    public String getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(String startPoint) {
        this.startPoint = startPoint;
    }

    public String getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(String endPoint) {
        this.endPoint = endPoint;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public Timestamp getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Timestamp createtime) {
        this.createtime = createtime;
    }

    public String getCableParam() {
        return cableParam;
    }

    public void setCableParam(String cableParam) {
        this.cableParam = cableParam;
    }

    public String getExtendFieldString() {
        return extendFieldString;
    }

    public void setExtendFieldString(String extendFieldString) {
        this.extendFieldString = extendFieldString;
    }

    public long getExtendFieldLong() {
        return extendFieldLong;
    }

    public void setExtendFieldLong(long extendFieldLong) {
        this.extendFieldLong = extendFieldLong;
    }

    public String getExtendFieldStringB() {
        return extendFieldStringB;
    }

    public void setExtendFieldStringB(String extendFieldStringB) {
        this.extendFieldStringB = extendFieldStringB;
    }

    public long getExtendFieldLongB() {
        return extendFieldLongB;
    }

    public void setExtendFieldLongB(long extendFieldLongB) {
        this.extendFieldLongB = extendFieldLongB;
    }

    public String getExtendFieldStringC() {
        return extendFieldStringC;
    }

    public void setExtendFieldStringC(String extendFieldStringC) {
        this.extendFieldStringC = extendFieldStringC;
    }

    public long getExtendFieldLongC() {
        return extendFieldLongC;
    }

    public void setExtendFieldLongC(long extendFieldLongC) {
        this.extendFieldLongC = extendFieldLongC;
    }

    public cable() {
    }

    public cable(long id, String cableName, long groupid, int cableNumber, String reservedCode, String cableCode, String manufacturer, float distance, int coreNumber, String cableDesc, String startPoint, String endPoint, String item, Timestamp createtime, String cableParam, String extendFieldString, long extendFieldLong, String extendFieldStringB, long extendFieldLongB, String extendFieldStringC, long extendFieldLongC) {
        this.id = id;
        this.cableName = cableName;
        this.groupid = groupid;
        this.cableNumber = cableNumber;
        this.reservedCode = reservedCode;
        this.cableCode = cableCode;
        this.manufacturer = manufacturer;
        this.distance = distance;
        this.coreNumber = coreNumber;
        this.cableDesc = cableDesc;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.item = item;
        this.createtime = createtime;
        this.cableParam = cableParam;
        this.extendFieldString = extendFieldString;
        this.extendFieldLong = extendFieldLong;
        this.extendFieldStringB = extendFieldStringB;
        this.extendFieldLongB = extendFieldLongB;
        this.extendFieldStringC = extendFieldStringC;
        this.extendFieldLongC = extendFieldLongC;
    }

    @Override
    public String toString() {
        return "cable{" +
                "id=" + id +
                ", cableName='" + cableName + '\'' +
                ", groupid=" + groupid +
                ", cableNumber=" + cableNumber +
                ", reservedCode='" + reservedCode + '\'' +
                ", cableCode='" + cableCode + '\'' +
                ", manufacturer='" + manufacturer + '\'' +
                ", distance=" + distance +
                ", coreNumber=" + coreNumber +
                ", cableDesc='" + cableDesc + '\'' +
                ", startPoint='" + startPoint + '\'' +
                ", endPoint='" + endPoint + '\'' +
                ", item='" + item + '\'' +
                ", createtime=" + createtime +
                ", cableParam='" + cableParam + '\'' +
                ", extendFieldString='" + extendFieldString + '\'' +
                ", extendFieldLong=" + extendFieldLong +
                ", extendFieldStringB='" + extendFieldStringB + '\'' +
                ", extendFieldLongB=" + extendFieldLongB +
                ", extendFieldStringC='" + extendFieldStringC + '\'' +
                ", extendFieldLongC=" + extendFieldLongC +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        cable cable = (cable) o;
        return Objects.equals(cableName, cable.cableName);
    }

    @Override
    public int hashCode() {

        return Objects.hash(cableName);
    }
}
