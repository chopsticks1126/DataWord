package com.ophylink.map.dao;

import com.ophylink.map.entity.user_permissions;

import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface user_permissionsMapper {
    /**
     *
     * @return
     * @throws Exception
     */
    public List<user_permissions> selAllUP() throws Exception;

    /**
     *根据用户ID 查询该用户的所有权限
     * @return
     * @throws Exception
     */
    public List<user_permissions> selectByUserId(Long userid) throws Exception;

    /**
     *添加用户的权限
     * @param list
     * @throws Exception
     */
    public boolean insertPermissesion(List<user_permissions> list) throws Exception;

    /**
     * 根据userid 删除已有的信息为准备后面编辑重写添加
     * @param userid
     * @return
     * @throws Exception
     */
    public  boolean deleByUserid(Long userid) throws Exception;
}
