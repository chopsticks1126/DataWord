package com.ophylink.map.web;

import com.ophylink.map.service.cablealarmServer;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
@RestController
@RequestMapping("/alarm")
public class cablealarmController {

    @Autowired
    private cablealarmServer server;

    /***
     * 获取全部光缆告警
     * @return
     */
    @ApiOperation(value = "获取全部光缆告警",notes = "获取全部光缆告警信息")
    @RequestMapping(value = "/getall",method = RequestMethod.POST)
    public HashMap getAllAlarm() {
        HashMap retMap = new HashMap();
        try{
            retMap.put("alarms",server.getAllAlarm());
            retMap.put("msg","get cablealarm success");
            retMap.put("code",1);
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","get cablealarm fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
        }
        return  retMap;
    }

    /**
     * 根据光缆ID获取光缆告警信息
     * @param cableids
     * @return
     */
    @ApiOperation(value = "获取多条光缆告警",notes = "获取多条光缆的告警信息")
    @ApiImplicitParam(value = "cableids",name = "光缆名称",required = true,dataType = "Long[]")
    @RequestMapping(value = "/getalarmbycableid",method = RequestMethod.POST)
    public HashMap getAlarmByCableId(Long[] cableids){

        HashMap retMap = new HashMap();
        try {
            List<Long> cableidlist = new ArrayList<>(Arrays.asList(cableids));
            retMap.put("alarms",server.getAlarmsByCableId(cableidlist));
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 根据光缆组ID获取光缆组下所有光缆的告警
     * @param groupids
     * @return
     */
    @ApiOperation(value = "获取多条光缆告警",notes = "获取多条光缆的告警信息")
    @ApiImplicitParam(value = "groupids",name = "光缆名称",required = true,dataType = "Long[]")
    @RequestMapping(value = "/getalarmbygroupid",method = RequestMethod.POST)
    public HashMap getAlarmByGroupId(Long[] groupids){

        HashMap retMap = new HashMap();
        try {
//            System.out.println(Arrays.asList(groupids));
            List<Long> groupidlist = new ArrayList<>(Arrays.asList(groupids));
            retMap.put("alarms",server.getAlarmsByGroupId(groupidlist));
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 根据光缆组ID获取光缆组下所有光缆的告警
     * @param cableids
     * @return
     */
    @ApiOperation(value = "获取多条光缆告警",notes = "获取多条光缆的告警信息")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "cableids",name = "光缆id",required = true,dataType = "Long[]"),
            @ApiImplicitParam(value = "groupids",name = "光缆组id",required = true,dataType = "Long[]"),
    })
    @RequestMapping(value = "/getalarmbyids",method = RequestMethod.POST)
    public HashMap getAlarmsByCableIdAndGroupId(Long[] cableids, Long[] groupids){
        HashMap retMap = new HashMap();
        try {
//            System.out.println(cableids);
//            System.out.println(groupids);
            HashMap<String,List<Long>> map = new HashMap<>();
            List<Long> cableids_list = new ArrayList<>(Arrays.asList(cableids));
            List<Long> groupids_list = new ArrayList<>(Arrays.asList(groupids));
            map.put("cableids",cableids_list);
            map.put("groupids",groupids_list);

            retMap.put("alarms",server.getAlarmsByIds(map));
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 根据告警ID删除一条告警
     * @param id
     * @return
     */
    @ApiOperation(value = "删除一个告警",notes = "根据告警id删除告警")
    @ApiImplicitParam(name="id",value = "id",required = true,dataType = "int",paramType="path")
    @RequestMapping(value = "/del",method = RequestMethod.POST)
    public HashMap deleteAlarm(int id){
        HashMap retMap = new HashMap();
        try{
            server.deleteAlarm(id);
            retMap.put("msg","delete cablealarm success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            retMap.put("msg","delete cablealarm fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 删除多个告警
     * @param ids
     * @return
     */
    @ApiOperation(value = "删除多个告警",notes = "根据告警id删除多个告警")
    @ApiImplicitParam(name="ids",value = "ids",required = true,dataType = "Long[]",paramType="path")
    @RequestMapping(value = "/dels",method = RequestMethod.POST)
    public HashMap deleteAlarms(Long[] ids){
        HashMap retMap = new HashMap();
        try{
            server.deleteAlarms(new ArrayList<Long>(Arrays.asList(ids)));
            retMap.put("msg","delete cablealarms success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            retMap.put("msg","delete cablealarms fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }
}
