package com.ophylink.map.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ophylink.map.entity.SessionData;
import com.ophylink.map.entity.permissions;
import com.ophylink.map.entity.user_permissions;
import com.ophylink.map.entity.userinfo;
import com.ophylink.map.service.PermissionService;
import com.ophylink.map.service.UserPermissionService;
import com.ophylink.map.service.userService;
import com.ophylink.map.util.DesUtil;
import com.ophylink.map.util.ResultUtil;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Created by MyPC on 2017/12/5.
 */
//@RestController
@Controller
@RequestMapping("/UserController")
public class userController {
    public static final String SESSION_KEY = "userSessionName";
    public static final Map<String,userinfo> loginMap = new HashMap<String, userinfo>();
    public static Logger logger= LoggerFactory.getLogger(userController.class);
    @Autowired
    private userService service;        //用户表
    @Autowired
    private PermissionService permissionService;    //权限表
    @Autowired
    private UserPermissionService userPermissionService;    //用户-权限

    @ApiOperation(value = "根据id获取用户信息", notes = "根据id获取用户信息")
    @GetMapping("/user")
    public HashMap userLogin() {
        HashMap map = new HashMap();
        try {
            List list = service.getall();
            map.put("user", list);
            map.put("code", 1);
            map.put("msg", "login success");
        } catch (Exception e) {
            System.out.println(e.getMessage());
            map.put("err", e.getMessage());
            map.put("code", 0);
            map.put("msg", "login fail");
        }
        return map;
    }
/*
    @ApiOperation(value = "添加用户or用户注册",notes = "添加用户/用户注册")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "uname", value = "用户名称", required = true, dataType = "String"),
            @ApiImplicitParam(name = "pass", value = "用户密码", required = true, dataType = "String"),
            @ApiImplicitParam(name = "role", value = "用具角色（0：超级管理员admin（具备所有权限） 1 普通用户只能有查看的权限2一般管理员 可以增加但是不能删除数据 ）", required = true, dataType = "int"),
            @ApiImplicitParam(name = "phone", value = "电话号码", required = true, dataType = "String"),
            @ApiImplicitParam(name = "email", value = "邮箱地址", required = true, dataType = "String"),
            @ApiImplicitParam(name = "type", value = "添加用户类型（1：用户注册 2：管理员添加）", required = true, dataType = "int"),
    })
    @GetMapping("/adduser/{uname}/{pass}/{role}/{phone}/{email}/{type}")
    public HashMap adduser(@PathVariable(value = "uname" ,required = true) String uname,
                           @PathVariable(value = "pass" ,required = true) String pass,
                           @PathVariable(value = "role" ,required = true) int role,
                           @PathVariable(value = "phone" ,required = true) String phone,
                           @PathVariable(value = "email" ,required = true) String email,
                           @PathVariable(value = "type" ,required = true) int type){
        HashMap map = new HashMap();
        try{
            if(service.isExist(uname.trim())==0) {
                mUser user = new mUser();
                user.setUname(uname);
                user.setPass(pass);
                user.setEmail(email);
                user.setPhone(phone);
                user.setRole(role);
                service.addUser(user);
                map.put("code", 1);
                map.put("msg", "add  success");
            }else {
                map.put("code", 2);
                map.put("msg", "the name is exist  try new name");
            }
        }catch (Exception e){
            map.put("err",e.getMessage());
            map.put("code",0);
            map.put("msg","login fail");
        }
        return map;
    }*/
    //GIS 系统功能
    /**
     * @author  wh
     */
    /**
     * 请求被拦截没有登录，跳转到登录界面（除ajax外）
     * @return
     */
    @RequestMapping("/loginIndex")
    public String loginIndex(HttpServletRequest request) {
            return "redirect:/map/login.html";
    }

    /**
     * 用户登录
     *
     * @param model
     * @param o     页面表单数据
     * @return
     */
    @RequestMapping(value = "/login", produces = "application/json")
    @ResponseBody
    public Map login(Model model, @RequestBody String o, HttpServletRequest request) {
        String sessionID = request.getRequestedSessionId();
        HttpSession session = request.getSession();
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            userinfo user = objectMapper.readValue(o, userinfo.class);
            String username = DesUtil.encrypt(user.getUsername());//加密查询
            String token = username;
            if (session != null && session.getAttribute(SESSION_KEY) != null) {
                userinfo result = (userinfo) request.getSession().getAttribute(SESSION_KEY);
                setSessionInfo(request, token, result);
                loginMap.put(token, result);
                Map map = new HashMap();
                map.put("message", "skip");
                map.put("username", DesUtil.decrypt(result.getUsername()));
                logger.info("已经登录咯");
                return map;
            } else {
                userinfo result = service.selectByLogin(username);
                if (result != null) {
                    if (result.getPassword() != null && result.getPassword() != "" && result.getPassword().equals(DesUtil.encrypt(user.getPassword()))) {
                        setSessionInfo(request, token, result);
                        SessionData.getSessionIDMap().put(result.getUsername(), sessionID);
                        request.setAttribute("userRequst", result);
                        logger.debug("开始登录......");
                        return ResultUtil.successMsg();
                    } else {
                        return ResultUtil.failMsg();
                    }
                } else {
                    return ResultUtil.failMsg();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            return ResultUtil.failMsg();
        }
    }

    /**
     * 将登录的信息存于session
     * @param request
     * @param token
     * @param result
     */
    public void setSessionInfo(HttpServletRequest request,String token,userinfo result){
        request.getSession().setAttribute(SESSION_KEY, result);
        request.getSession().setAttribute("userNameCode", token);
    SessionData.getSessionIDMap().put("userNameCode",token);
}
    /**
     * 校验是否为管理员权限登录
     * @param request
     * @return
     */
    @RequestMapping("/checkPermissions")
    @ResponseBody
    public Map checkPermissions(HttpServletRequest request) {
        HttpSession session = request.getSession();
        if (session != null) {
            userinfo userinfo = (userinfo) request.getSession().getAttribute(SESSION_KEY);//将成功登录的用户信息存入session
            if (userinfo != null) {
                if (userinfo.getUsername().equals("TCjuiP0hNr0=")) {//检验是否为管理员
                    logger.info("管理员登录。");
                    return ResultUtil.successMsg();
                } else {
                    return ResultUtil.failMsg();
                }
            } else {
                return ResultUtil.failMsg();
            }
        } else {
            return ResultUtil.failMsg();
        }
    }

    /**
     * 用户注册
     * @param model
     * @param o     页面表单数据
     * @return
     */
    @RequestMapping(value = "/signUp", produces = "application/json")
    @ResponseBody
    public Map signUp(Model model, @RequestBody String o) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            userinfo user = objectMapper.readValue(o, userinfo.class);
            user.setPassword(DesUtil.encrypt(user.getPassword()));
            user.setUserchinaname(DesUtil.encrypt((user.getUsername())));//用户名即为用户显示名称
            user.setCreatetime(new Date());//增加时间
            user.setId(System.currentTimeMillis());
            user.setUsername(DesUtil.encrypt((user.getUsername())));
            if (service.signUp(user)) {
                logger.info("注册成功。");
                return ResultUtil.successMsg();
            } else{
                logger.info("注册失败。");
                return ResultUtil.failMsg();
            }
        } catch (Exception e) {
            e.printStackTrace();
            logger.debug("出现异常.....");
            return ResultUtil.failMsg();
        }
    }

    /**
     * 首页取得登录用户信息
     * @param request
     * @return
     */
    @RequestMapping(value = "/check", produces = "application/json")
    @ResponseBody
    public Map check(HttpServletRequest request) {
        userinfo user = null;
        Map<String, Object> map = new HashMap();
        if ((request.getSession().getAttribute(SESSION_KEY)) != null) {
            user = (userinfo) request.getSession().getAttribute(SESSION_KEY);
            try {
                request.getSession().setAttribute(SESSION_KEY, user);
                map.put("username", DesUtil.decrypt(user.getUsername()));
                logger.info("取用户信息。");
                map.put("message", "success");
            } catch (Exception e) {
                e.printStackTrace();
                ResultUtil.failMsg();
            }
            return map;
        } else {
            return ResultUtil.failMsg();
        }
    }

    /**
     * 所有用户的权限显示及配置信息
     * @return
     */
    @RequestMapping(value = "/getAllPermission", produces = "application/json")
    @ResponseBody
    public Map getAllPermission(String page, String pageSize) {
        try {
            Map map = service.selectAllUser(page, pageSize);
            List<permissions> Permission = permissionService.selAllPs();
            List<user_permissions> userPermission = userPermissionService.selAllUP();
            map.put("dataInfos", Permission);
            map.put("userPermissions", userPermission);
            logger.info("获取所有用户的权限显示及配置信息。");
            return map;
        } catch (Exception e) {
            e.printStackTrace();
            return ResultUtil.failMsg();
        }
    }

    /**
     * 修改用户的权限
     * @return
     */
    @RequestMapping(value = "/updatePermission", produces = "application/json")
    @ResponseBody
    public synchronized Map updatePermission(String userid, String checkStr) {
        Map<String, String> oldUpMap = new HashMap<>();
        try {
            oldUpMap = userPermissionService.changePermission(userid, checkStr);
            logger.info("成功修改用户权限");
            return ResultUtil.successMsg();
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("修改用户权限失败");
            return ResultUtil.failMsg();
        }
    }

    /**
     * 校验注册用户名是否已经被注册
     *
     * @param username
     * @return
     */
    @RequestMapping(value = "/signUpCheckUserName", produces = "application/json")
    @ResponseBody
    public Map signUpCheckUserName(String username) {
        if (username != null && !("").equals(username)) {
            logger.info("该用户名："+username+",已经被注册！");
            return service.checkName(username);
        } else {
            logger.info("校验注册用户名情况失败！");
            return ResultUtil.failMsg();
        }
    }

    /**
     * 获取用户权限表数据
     * @return
     */
    @RequestMapping(value = "/getUserPermissions", produces = "application/json")
    @ResponseBody
    public Map getUserPermissions() {
        Map<String, Object> upMap = new HashMap<>();
        try {
            List<user_permissions> userPermission = userPermissionService.selAllUP();
            upMap.put("userPermissions", userPermission);
            upMap.put("message", "success");
            logger.info("成功获取用户权限表数据");
            return upMap;
        } catch (Exception e) {
            e.printStackTrace();
            logger.info("获取用户权限表数据失败！"+e);
            return ResultUtil.failMsg();
        }
    }

    /**
     * 登录退出
     *
     * @param request
     * @return
     */
    @RequestMapping("/loginOut")
    public String loginOut(HttpServletRequest request) {
        Map<String, String> retMap = new HashMap<String, String>();
        Enumeration em = request.getSession().getAttributeNames();
       String token = (String) request.getSession().getAttribute("userNameCode");
        loginMap.remove(token);
        SessionData.getSessionIDMap().remove("userNameCode");
        while (em.hasMoreElements()) {
            request.getSession().removeAttribute(em.nextElement().toString());
            logger.info("用户登录退出。");
        }

        return "redirect:/map/login.html";
    }
//    @RequestMapping("/loginCheck")
//    @ResponseBody
//    public Map<String, String> loginCheck(HttpServletRequest request) {
//        Map<String,String> retMap = new HashMap<String, String>();
//        HttpSession session = request.getSession();
//        if (session != null) {
//            retMap.put("message","success");
//            request.getSession().setAttribute(SESSION_KEY, session.getAttribute(SESSION_KEY));//将成功登录的用户信息存入session
//        }else {
//            retMap.put("message","fail");
//        }
//        return retMap;
//    }
}
