package com.ophylink.map.web;

import com.ophylink.map.entity.cable;
import com.ophylink.map.entity.cablegroup;
import com.ophylink.map.entity.cablepoint;
import com.ophylink.map.service.cableServer;
import com.ophylink.map.service.cablegroupServer;
import com.ophylink.map.service.cablepointServer;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

/**
 * Created by MyPC on 2018/3/5.
 */
@RestController
@RequestMapping("/point")
public class cablepointController {

    @Autowired
    private cablepointServer server;
    @Autowired
    private cablegroupServer groupserver;
    @Autowired
    private cableServer cableserver;

    /***
     * 获取全部光缆节点
     * @return
     */
    @ApiOperation(value = "获取全部光缆节点",notes = "获取全部光缆节点信息")
    @RequestMapping(value = "/getall",method = RequestMethod.POST)
    public HashMap getAllPoint() {
        HashMap retMap = new HashMap();
        try{
            retMap.put("points",server.getAllPoint());
            retMap.put("msg","get cablepoint success");
            retMap.put("code",1);
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","get cablepoint fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
        }
        return  retMap;
    }

    /**
     *  根据光缆节点名称获取光缆节点
     * @param pointName
     * @return
     */
    @ApiOperation(value = "获取一条光缆节点",notes = "获取一条光缆节点的信息")
    @ApiImplicitParam(value = "pointName",name = "光缆节点名称",required = true,dataType = "String")
    @RequestMapping(value = "/getpointbypointname",method = RequestMethod.POST)
    public HashMap getPointByPointName(String pointName){

        HashMap retMap = new HashMap();
        try {
            retMap.put("point",server.getPointByPointName(pointName));
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 根据光缆ID获取光缆下所有节点
     * @param cableid
     * @return
     */
    @ApiOperation(value = "获取一条光缆下所有节点",notes = "获取一条光缆下所有节点的信息")
    @ApiImplicitParam(value = "cableid",name = "光缆Id",required = true,dataType = "long")
    @RequestMapping(value = "/getpointbycableid",method = RequestMethod.POST)
    public HashMap getPointByCableName(long cableid){
        HashMap retMap = new HashMap();
        try {
            retMap.put("points",server.getPointsByCableId(cableid));
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 添加一个光缆节点
     * @param cableid
     * @param pointName
     * @param pointDesc
     * @param longitude
     * @param latitude
     * @param beforepointid
     * @param distance
     * @param cableName
     * @param pointParam
     * @return
     */
    @ApiOperation(value = "添加一个光缆节点",notes = "添加一个光缆节点信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name="cableid",value = "父组id",required = true,dataType = "long"),
            @ApiImplicitParam(name="pointName",value = "光缆节点的名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="pointDesc",value = "光缆节点的显示名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="longitude",value = "经度",required = true,dataType = "double"),
            @ApiImplicitParam(name="latitude",value = "纬度",required = true,dataType = "double"),
            @ApiImplicitParam(name="beforepointid",value = "前光缆节点ID",required = true,dataType = "long"),
            @ApiImplicitParam(name="distance",value = "距离",required = true,dataType = "float"),
            @ApiImplicitParam(name="cableName",value = "光缆名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="pointParam",value = "备注",required = true,dataType = "String"),
            @ApiImplicitParam(name="extendFieldString",value = "前光缆节点名称",required = true,dataType = "String")

    })
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public HashMap addPoint(
            long cableid,
            String pointName,
            String pointDesc,
            double longitude,
            double latitude,
            long beforepointid,
            float distance,
            String cableName,
            String pointParam,
            String extendFieldString
        ){
        HashMap retMap = new HashMap();
        try {
            cablepoint point = new cablepoint();
            point.setCableid(cableid);
            point.setPointName(pointName);
            point.setPointDesc(pointDesc);
            point.setLongitude(longitude);
            point.setLatitude(latitude);
            point.setBeforepointid(beforepointid);
            point.setDistance(distance);
            point.setCableName(cableName);
            point.setPointParam(pointParam);
            point.setExtendFieldString(extendFieldString);
            server.addPoint(point);
            retMap.put("msg","add cablepoint success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","add cablepoint fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 修改光缆节点
     * @param id
     * @param cableid
     * @param pointDesc
     * @param longitude
     * @param latitude
     * @param distance
     * @param beforepointid
     * @param cableName
     * @param pointParam
     * @return
     */
    @ApiOperation(value = "修改一个光缆节点",notes = "修改一个光缆节点信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value = "id",required = true,dataType = "long"),
            @ApiImplicitParam(name="cableid",value = "父组id",required = true,dataType = "String"),
            @ApiImplicitParam(name="pointDesc",value = "光缆节点的显示名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="longitude",value = "经度",required = true,dataType = "float"),
            @ApiImplicitParam(name="latitude",value = "纬度",required = true,dataType = "float"),
            @ApiImplicitParam(name="beforepointid",value = "前光缆节点ID",required = true,dataType = "long"),
            @ApiImplicitParam(name="distance",value = "距离",required = true,dataType = "float"),
            @ApiImplicitParam(name="cableName",value = "光缆名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="pointParam",value = "备注",required = true,dataType = "String"),
            @ApiImplicitParam(name="extendFieldString",value = "前光缆节点名称",required = true,dataType = "String")
    })
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public HashMap updatePoint(
            long id,
            long cableid,
            String pointDesc,
            float longitude,
            float latitude,
            float distance,
            long beforepointid,
            String cableName,
            String pointParam,
            String extendFieldString
    ){
        HashMap retMap = new HashMap();
        try {
            cablepoint point = new cablepoint();
            point.setId(id);
            point.setCableid(cableid);
            point.setPointDesc(pointDesc);
            point.setLongitude(longitude);
            point.setLatitude(latitude);
            point.setBeforepointid(beforepointid);
            point.setDistance(distance);
            point.setCableName(cableName);
            point.setPointParam(pointParam);
            point.setExtendFieldString(extendFieldString);
            server.updatePoint(point);
            retMap.put("msg","update cablepoint success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","update cablepoint fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 删除光缆
     * @param id
     * @return
     */

    @ApiOperation(value = "删除一个光缆节点",notes = "根据光缆节点id删除光缆节点")
    @ApiImplicitParam(name="id",value = "id",required = true,dataType = "int",paramType="path")
    @RequestMapping(value = "/del",method = RequestMethod.POST)
    public HashMap deletePoint(int id){
        HashMap retMap = new HashMap();
        try{
            server.deletePoint(id);
            retMap.put("msg","delete cablepoint success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            retMap.put("msg","delete cablepoint fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /***
     * 获取全部光缆节点及前节点的经纬度
     * @return
     */
    @ApiOperation(value = "获取全部光缆节点",notes = "获取全部光缆节点信息")
    @RequestMapping(value = "/getline",method = RequestMethod.POST)
    public HashMap getPointsByPointId() {
        HashMap retMap = new HashMap();
        try{
            List<HashMap> list = server.getPointsByPointId();
            retMap.put("lines",list);
            retMap.put("msg","get line success");
            retMap.put("code",1);
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","get line fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
        }
        return  retMap;
    }

    @ApiOperation(value = "获取光缆节点",notes = "获取光缆节点的信息")
    @ApiImplicitParams({
            @ApiImplicitParam(value = "cableids",name = "光缆Ids",required = true,dataType = "Long[]"),
            @ApiImplicitParam(value = "groupids",name = "光缆组Ids",required = true,dataType = "Long[]"),
            @ApiImplicitParam(value = "pointids",name = "光缆节点Ids",required = true,dataType = "Long[]")
    })
    @RequestMapping(value = "/getpointbyids",method = RequestMethod.POST)
    public HashMap getPointByIds(Long[] cableids,Long[] groupids,Long[] pointids){
        HashMap retMap = new HashMap();
        try {
            System.out.println("----------------------");
            System.out.println(cableids);
            System.out.println(pointids);
            System.out.println("----------------------");
            //得到所有选中的光缆组及光缆组子级
            List<Long> groupidlist = new ArrayList<>(Arrays.asList(groupids));
            List<Long> groupids1 = getAllGroupIdsByIds(groupidlist,groupidlist);
            //得到所有选中的光缆及光缆组下的光缆
            List<Long> cableidlist = new ArrayList<>(Arrays.asList(cableids));
            List<Long> cableids1 = getAllCableIdsByGroupIds(cableidlist,groupids1);
            //得到所有选中的光缆节点
            List<Long> pointidlist = new ArrayList<>(Arrays.asList(pointids));
            List<cablepoint> cablepoints = new ArrayList<>();
            if ((cableids1 != null && cableids1.size() > 0) || (pointidlist != null && pointidlist.size() > 0)){
                HashMap<String,List<Long>> map = new HashMap();
                map.put("cableids", cableids1);
                map.put("pointids", pointidlist);
                cablepoints = server.getCableByIdsAndCableIds(map);
            }
            retMap.put("points",cablepoints);
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 级联查询，根据光缆组ID得到所有光缆组ID
     * @param ids
     * @return
     */
    public List<Long> getAllGroupIdsByIds(List<Long> groupids,List<Long> ids) {
        try {
            List<cablegroup> groups = groupserver.getGroupByGroupPIds(ids);
            Iterator it = groups.iterator();
            while (it.hasNext()) {
                cablegroup group = (cablegroup) it.next();
                if (!groupids.contains(group.getId())){
                    groupids.add(group.getId());
//                    System.out.println(group.getId() + "---------------");
                }
                List<Long> list = new ArrayList<>();
                list.add(group.getId());
                getAllGroupIdsByIds(groupids,list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return groupids;
    }

    /**
     * 根据光缆组ID得到所有光缆ID
     * @param cableids
     * @param groupids
     * @return
     */
    public List<Long> getAllCableIdsByGroupIds(List<Long> cableids,List<Long> groupids) {
        try {
            if (groupids != null && groupids.size() > 0){
                List<cable> cables = cableserver.getCableByPIds(groupids);
                Iterator it = cables.iterator();
                while (it.hasNext()) {
                    cable cable = (cable) it.next();
                    if (!cableids.contains(cable.getId())){
                        cableids.add(cable.getId());
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return cableids;
    }
}
