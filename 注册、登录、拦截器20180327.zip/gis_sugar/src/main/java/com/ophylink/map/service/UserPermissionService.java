package com.ophylink.map.service;

import com.ophylink.map.dao.user_permissionsMapper;
import com.ophylink.map.entity.user_permissions;
import com.ophylink.map.util.ResultUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by MyPC on 2017/12/5.
 */
@Service
public class UserPermissionService {

    @Autowired
    private user_permissionsMapper userPermissionsMapper;

    /**
     * 查询用户权限数据
     * @return
     * @throws Exception
     */
    public List<user_permissions> selAllUP() throws Exception{

        return userPermissionsMapper.selAllUP();
    }

    /**
     *根据用户ID 查询该用户的所有权限
     * @return
     * @throws Exception
     */
    public List<user_permissions> selectByUserId(Long userid) throws Exception{

        return userPermissionsMapper.selectByUserId(userid);
    }

    /**
     *添加用户的权限
     * @param list
     * @return
     * @throws Exception
     */
    @Transactional
    public boolean insertPermissesion(List<user_permissions> list) throws Exception{

        return userPermissionsMapper.insertPermissesion(list);
    }

    /**
     *修改权限配置
     * @param userid
     * @param checkStr
     * @return
     * @throws Exception
     */
    @Transactional(rollbackFor = Exception.class)
    public Map changePermission(String userid, String checkStr) throws Exception {
        userPermissionsMapper.deleByUserid(Long.parseLong(userid));
        List<user_permissions> listup = new ArrayList<>();
        user_permissions updto = null;
        Map<String, String> newUpMap = new HashMap<>();
        if (checkStr != null && !("").equals(checkStr)) {
            String[] checked = checkStr.split(",");
            for (String ck : checked) {
                updto = new user_permissions();
                updto.setUserid(Long.parseLong(userid));
                updto.setPermissionsenid(Integer.parseInt(ck));
                newUpMap.put(ck, userid);
                listup.add(updto);
            }
            userPermissionsMapper.insertPermissesion(listup);
        }
        return ResultUtil.successMsg();
    }
}
