package com.ophylink.map.dao;

import com.ophylink.map.entity.cablepoint;

import java.util.HashMap;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface cablepointMapper {
    /***
     *获取全部光缆节点的信息
     * @return
     * @throws Exception
     */
    public List<cablepoint> getAllPoint() throws Exception;

    /**
     * 添加一个光缆
     * @param point
     * @return
     * @throws Exception
     */
    public boolean addPoint(cablepoint point) throws Exception;

    /**
     * 更新一个光缆
     * @param point
     * @return
     * @throws Exception
     */
    public boolean updatePoint(cablepoint point) throws Exception;

    /***
     * 删除一个光缆
     * @param id
     * @return
     * @throws Exception
     */
    public boolean deletePoint(int id) throws Exception;

    /**
     * 获取一个光缆
     * @param pointName
     * @return
     * @throws Exception
     */
    public cablepoint getPointByPointName(String pointName) throws Exception;

    /**
     * 根据光缆ID获取光缆节点信息
     * @param cableId
     * @return
     * @throws Exception
     */
    public List<cablepoint> getPointsByCableId(long cableId) throws Exception;

    /**
     * 获取所有光缆节点及前节点的经纬度
     * @return
     * @throws Exception
     */
    public List<HashMap> getPointsByPointId() throws Exception;

    /**
     * 根据光缆ID获取光缆节点
     * @param Ids
     * @return
     * @throws Exception
     */
    public List<cablepoint> getCableByIdsAndCableIds(HashMap<String,List<Long>> Ids) throws Exception;
}
