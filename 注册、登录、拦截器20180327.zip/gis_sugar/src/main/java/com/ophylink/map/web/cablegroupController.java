package com.ophylink.map.web;

import com.ophylink.map.entity.cablegroup;
import com.ophylink.map.service.cablegroupServer;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;

/**
 * Created by MyPC on 2018/3/5.
 */
@RestController
@RequestMapping("/group")
public class cablegroupController {

    @Autowired
    private cablegroupServer server;

    /***
     * 获取全部光缆组
     * @return
     */
    @ApiOperation(value = "获取全部光缆组",notes = "获取全部光缆组信息")
    @RequestMapping(value = "/getall",method = RequestMethod.POST)
    public HashMap getAllGroup() {
        HashMap retMap = new HashMap();
        try{
            retMap.put("groups",server.getAllGroup());
            retMap.put("msg","get cablegroup success");
            retMap.put("code",1);
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","get cablegroup fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
        }
        return  retMap;
    }

    /**
     *  根据光缆组名称获取光缆组
     * @param groupname
     * @return
     */
    @ApiOperation(value = "获取一条光缆组",notes = "获取一条光缆组的信息")
    @ApiImplicitParam(value = "groupname",name = "光缆组名称",required = true,dataType = "String")
    @RequestMapping(value = "/getgroupbygroupname",method = RequestMethod.POST)
    public HashMap getGroupByGroupName(String groupname){

        HashMap retMap = new HashMap();
        try {
            retMap.put("group",server.getGroupByGroupName(groupname));
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 添加光缆组
     * @param pid
     * @param groupName
     * @param groupDesc
     * @param parentGroup
     * @param district
     * @param entryUser
     * @param groupParam
     * @return
     */
    @ApiOperation(value = "添加一个光缆组",notes = "添加一个光缆组信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name="pid",value = "父组id",required = true,dataType = "int"),
            @ApiImplicitParam(name="groupName",value = "光缆组的名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="groupDesc",value = "光缆组的显示名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="parentGroup",value = "光缆组父组的名称",required = true,dataType = "string"),
            @ApiImplicitParam(name="district",value = "区域",required = true,dataType = "String"),
            @ApiImplicitParam(name="entryUser",value = "负责人",required = true,dataType = "String"),
            @ApiImplicitParam(name="groupParam",value = "备注",required = true,dataType = "String")
    })
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    public HashMap addGroup(int pid,
                           String groupName,
                           String groupDesc,
                           String parentGroup,
                           String district,
                           String entryUser,
                           String groupParam){
        HashMap retMap = new HashMap();
        try {
            cablegroup group = new cablegroup();
            group.setGroupName(groupName);
            group.setGroupDesc(groupDesc);
            group.setParentGroup(parentGroup);
            group.setDistrict(district);
            group.setEntryUser(entryUser);
            group.setGroupParam(groupParam);
            group.setExtendFieldLong(pid);
            server.addGroup(group);
            retMap.put("msg","add cablegroup success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","add cablegroup fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 修改光缆组
     * @param id
     * @param pid
     * @param groupDesc
     * @param parentGroup
     * @param district
     * @param entryUser
     * @param groupParam
     * @return
     */
    @ApiOperation(value = "修改一个光缆组",notes = "修改一个光缆组信息")
    @ApiImplicitParams({
            @ApiImplicitParam(name="id",value = "id",required = true,dataType = "int"),
            @ApiImplicitParam(name="pid",value = "父组id",required = true,dataType = "int"),
            @ApiImplicitParam(name="groupDesc",value = "光缆组的显示名称",required = true,dataType = "String"),
            @ApiImplicitParam(name="parentGroup",value = "光缆组父组的名称",required = true,dataType = "string"),
            @ApiImplicitParam(name="district",value = "区域",required = true,dataType = "String"),
            @ApiImplicitParam(name="entryUser",value = "负责人",required = true,dataType = "String"),
            @ApiImplicitParam(name="groupParam",value = "备注",required = true,dataType = "String")
    })
    @RequestMapping(value = "/update",method = RequestMethod.POST)
    public HashMap updateGroup(
            int id,
            int pid,
            String groupDesc,
            String parentGroup,
            String district,
            String entryUser,
            String groupParam
    ){
        HashMap retMap = new HashMap();
        try {
            cablegroup group = new cablegroup();
            group.setId(id);
            group.setGroupDesc(groupDesc);
            group.setParentGroup(parentGroup);
            group.setDistrict(district);
            group.setEntryUser(entryUser);
            group.setGroupParam(groupParam);
            group.setExtendFieldLong(pid);
            server.updateGroup(group);
            retMap.put("msg","update cablegroup success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","update cablegroup fail");
            retMap.put("code",-1);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     * 删除光缆组
     * @param id
     * @return
     */

    @ApiOperation(value = "删除一个光缆组",notes = "根据光缆组id删除光缆组")
    @ApiImplicitParam(name="id",value = "id",required = true,dataType = "int",paramType="path")
    @RequestMapping(value = "/del",method = RequestMethod.POST)
    public HashMap deleteGroup(int id){
        HashMap retMap = new HashMap();
        try{
            server.deleteGroup(id);
            retMap.put("msg","delete cablegroup success");
            retMap.put("code",1);
            return retMap;
        }catch (Exception e){
            retMap.put("msg","delete cablegroup fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());
            return retMap;
        }
    }

    /**
     *  根据光缆组ID获取光缆组
     * @param groupids
     * @return
     */
    @ApiOperation(value = "获取多条条光缆组",notes = "获取多条光缆组的信息")
    @ApiImplicitParam(value = "groupids",name = "光缆组Ids",required = true,dataType = "Long[]")
    @RequestMapping(value = "/getgroupbyids",method = RequestMethod.POST)
    public HashMap getGroupByGroupIds(Long[] groupids){

        HashMap retMap = new HashMap();
        try {
            //根据选中的光缆组ID得到光缆组
            List<Long> groupidlist = new ArrayList<>(Arrays.asList(groupids));
            List<cablegroup> groups1 = server.getGroupByGroupIds(groupidlist);//根据ID查询
            //根据选中的光缆组ID得到光缆组子级
            List<cablegroup> groups = getAllGroup(groups1,groupidlist);//根据父组ID查询
            retMap.put("groups",groups);
            retMap.put("msg","success");
            retMap.put("code",1);

        }catch (Exception e){
            e.printStackTrace();
            retMap.put("msg","fail");
            retMap.put("code",0);
            retMap.put("res",e.getMessage());

        }
        return retMap;
    }

    /**
     * 级联查询
     * @param ids
     * @return
     */
    public List<cablegroup> getAllGroup(List<cablegroup> cablegroups,List<Long> ids) {
        try {
            List<cablegroup> groups = server.getGroupByGroupPIds(ids);
            Iterator it = groups.iterator();
            while (it.hasNext()) {
                cablegroup group = (cablegroup) it.next();
                if (!cablegroups.contains(group)){//去重判断,该类重写了equals()方法和hashCode()方法，根据光缆组名称判断
                    cablegroups.add(group);
                }
                List<Long> list = new ArrayList<>();
                list.add(group.getId());
                getAllGroup(cablegroups,list);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return cablegroups;
    }
}
