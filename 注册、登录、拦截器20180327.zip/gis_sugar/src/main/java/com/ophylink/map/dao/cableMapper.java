package com.ophylink.map.dao;

import com.ophylink.map.entity.cable;

import java.util.HashMap;
import java.util.List;

/**
 * Created by MyPC on 2018/3/5.
 */
public interface cableMapper {
    /***
     *获取全部光缆的信息
     * @return
     * @throws Exception
     */
    public List<cable> getAllCable() throws Exception;

    /**
     * 添加一个光缆
     * @param cable
     * @return
     * @throws Exception
     */
    public boolean addCable(cable cable) throws Exception;

    /**
     * 更新一个光缆
     * @param cable
     * @return
     * @throws Exception
     */
    public boolean updateCable(cable cable) throws Exception;

    /***
     * 删除一个光缆
     * @param id
     * @return
     * @throws Exception
     */
    public boolean deleteCable(int id) throws Exception;

    /**
     * 获取一个光缆
     * @param cableName
     * @return
     * @throws Exception
     */
    public cable getCableByCableName(String cableName) throws Exception;

    /**
     * 根据光缆组ID查询光缆组下所有光缆
     * @param groupids
     * @return
     * @throws Exception
     */
    public List<cable> getCableByPIds(List<Long> groupids) throws Exception;

    /**
     * 根据光缆组ID和光缆ID查询所有光缆
     * @param map
     * @return
     * @throws Exception
     */
    public List<cable> getCableByIds(HashMap<String,List<Long>> map) throws Exception;
}
