var zTreeObj;
// zTree 的参数配置，深入使用请参考 API 文档（setting 配置详解）
var setting = {
    view: {
        // showIcon: showIconForTree,
        dblClickExpand: dblClickExpand,
        fontCss: getFontCss
    },
    data: {
        simpleData: {
            enable: true
        },
        key: {
            title: "t"
        },
        simpleData: {
            enable: true
        }
    },
    callback: {
        // beforeMouseDown: beforeMouseDown,
        // beforeMouseUp: beforeMouseUp,
        // beforeRightClick: beforeRightClick,
        onMouseDown: onMouseDown,
        // onMouseUp: onMouseUp,
        // onRightClick: onRightClick
    }
};
//光缆组ID 光缆组父组ID 光缆组名称  open:true
//光缆ID 光缆组ID 光缆名称  open:true
//光缆节点ID 光缆ID 光缆节点名称
var zNodes =getNodes();
//     [
//     { id:1, pId:0, name:"根 Root", open:true},
//     { id:11, pId:1, name:"父节点 1-1", open:true,icon:"../img/cable/group.png"},
//     { id:111, pId:11, name:"叶子节点 1-1-1",icon:"../img/cable/cable.png"},
//     { id:112, pId:11, name:"叶子节点 1-1-2",icon:"../img/cable/cable.png"},
//     { id:113, pId:11, name:"叶子节点 1-1-3",icon:"../img/cable/cable.png"},
//     { id:114, pId:11, name:"叶子节点 1-1-4",icon:"../img/cable/cable.png"},
//     { id:12, pId:1, name:"父节点 1-2", open:true,icon:"../img/cable/group.png"},
//     { id:121, pId:12, name:"叶子节点 1-2-1",icon:"../img/cable/cable.png"},
//     { id:122, pId:12, name:"叶子节点 1-2-2",icon:"../img/cable/cable.png"},
//     { id:123, pId:12, name:"叶子节点 1-2-3",icon:"../img/cable/cable.png"},
//     { id:124, pId:12, name:"叶子节点 1-2-4",icon:"../img/cable/cable.png"},
//     { id:13, pId:1, name:"父节点 1-3", open:true,icon:"../img/cable/group.png"},
//     { id:131, pId:13, name:"叶子节点 1-3-1",icon:"../img/cable/cable.png"},
//     { id:132, pId:13, name:"叶子节点 1-3-2",icon:"../img/cable/cable.png"},
//     { id:133, pId:13, name:"叶子节点 1-3-3", open:true,icon:"../img/cable/cable.png"},
//     { id:134, pId:13, name:"叶子节点 1-3-4",icon:"../img/cable/cable.png"},
//     { id:1331, pId:133, name:"叶子节点 1-3-3-1",icon:"../img/cable/point.png"},
//     { id:1332, pId:133, name:"叶子节点 1-3-3-2",icon:"../img/cable/point.png"},
//     { id:1334, pId:133, name:"叶子节点 1-3-3-4",icon:"../img/cable/point.png"}
//   ];

function getNodes() {
    var nodes = [];
    var i_max = 0;
    //得到所有光缆组
    $.ajax({
        type : 'POST',
        url : "/group/getall",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            var groups = data.groups;
            // alert("你查询的数据条数为："+groups.length);
            if(groups != null && groups.length > 0){
                i_max  = groups.length;
                for(var i=0;i < i_max;i++){
                    var group = groups[i];
                    var groupname = group.groupName;
                    if(group.groupDesc != ""){
                        groupname = group.groupDesc;
                    }
                    nodes[i] = {id: group.id, pId : group.extendFieldLong, name : groupname, open:true, icon:"../../img/cable/group.png"};
                }
            }
        },
        error : function(data) {
            // console.log("----------- fail-------------");
        }
    });
    // console.log(nodes);
    //得到所有光缆
    $.ajax({
        type : 'POST',
        url : "/cable/getall",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            var cables = data.cables;
            // alert("你查询的数据条数为："+groups.length);
            if(cables != null && cables.length > 0){
                for(var i=i_max;i < cables.length+i_max;i++){
                    var cable = cables[i-i_max];
                    // console.log(cable);
                    var cableName = cable.cableName;
                    if(cable.cableDesc != ""){
                        cableName = cable.cableDesc;
                    }
                    nodes[i] = {id: cable.id+"Q", pId : cable.groupid, name : cableName, open:true, icon:"../../img/cable/cable.png"};
                }
                i_max += cables.length;
            }
        },
        error : function(data) {
            // console.log("----------- fail-------------");
        }
    });
    // console.log(nodes);
    //得到所有光缆节点
    $.ajax({
        type : 'POST',
        url : "/point/getall",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            var points = data.points;
            if (points != null && points.length > 0){
                for(var i=i_max;i < points.length+i_max;i++){
                    var point = points[i-i_max];
                    // console.log(point);
                    var pointName = point.cableName;
                    if(point.pointDesc != ""){
                        pointName = point.pointDesc;
                    }
                    nodes[i] = {id: point.id+"W", pId : point.cableid+"Q", name : pointName, icon:"../../img/cable/point.png"};
                }
            }
        },
        error : function(data) {
            // console.log("----------- fail-------------");
        }
    });
    return nodes;
}

function showIconForTree(treeId, treeNode) {
    return !treeNode.isParent;
}

function dblClickExpand(treeId, treeNode) {
    return treeNode.level > 0;
}

function onMouseDown(event, treeId, treeNode) {
    // console.log(treeNode);
    // console.log(treeId);
    // console.log(event);
    if(treeNode == null){
        // var treeObj = $.fn.zTree.getZTreeObj("treeDemo");
        zTreeObj.checkAllNodes(false);
    }
}

function refresh() {
    // console.log("-------刷新树结构---------");
    zNodes = getNodes();
    zTreeObj = $.fn.zTree.init($("#treeDemo"), setting, zNodes);
}


//搜索方法，根据名称关键字搜索定位---开始
var nodeList = [];
function searchNode() {
    updateNodes(false);//清楚上一次的选中记录

    var key = $("#key");
    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
    var keyType = "name";//根据名称搜索
    var value = key.get(0).value;
    // console.log(value);
    // console.log(keyType);
    if (value === "") return;//如果输入为null，直接返回
    nodeList = zTree.getNodesByParamFuzzy(keyType, value);//搜索方法
    updateNodes(true);

}
function updateNodes(highlight) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo");
    for( var i=0, l=nodeList.length; i<l; i++) {
        nodeList[i].highlight = highlight;
        zTree.updateNode(nodeList[i]);
        if(i == 0){
            zTree.selectNode(nodeList[i]);
        }
    }
}
function getFontCss(treeId, treeNode) {
    return (!!treeNode.highlight) ? {color:"#A60000", "font-weight":"bold"} : {color:"#333", "font-weight":"normal"};
}
//---------------------------------------结束
