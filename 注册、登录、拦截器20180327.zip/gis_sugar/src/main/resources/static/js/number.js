//正则表达式判断是不是一个正整数
function checkInteger(num) {
    var result = -1;
    var re = /[1−9]+[0−9]*/;//判断字符串是否为数字//判断正整数/[1−9]+[0−9]∗]∗/
    if (!re.test(num)) {
        result = 1;
        // alert("请输入一个正整数");
    }
    return result;
}

//正则表达式判断是不是一个数字，包含小数点
function checkDouble(num) {
    var re = /^[0-9]+.?[0-9]*/;//判断字符串是否为数字//判断正整数/[1−9]+[0−9]∗]∗/
    if (!re.test(num)) {
        alert("请输入一个数字");
    }
}