var map;
$(function(){
//新建一个地图
    map = new AMap.Map('container', {
        resizeEnable: true,
        zoom:6,
        center: [104.06, 30.5]
    });

    //增加控件：缩放控制条-地图工具条（ToolBar）、缩略图-鹰眼(OverView)、比例尺（Scale）
    AMap.plugin(['AMap.ToolBar','AMap.Scale'],
        function() {
            map.addControl(new AMap.ToolBar());

            map.addControl(new AMap.Scale());
        });
});




//初始化地图对象，加载数据
function mapInit(){
    map.clearMap();
    //点
    // var points = new Array();
    // points[0] = {"longitude":"104.06" , "latitude":"30.5"};
    // points[1] = {"longitude":"114.27" , "latitude":"30.58" };
    // points[2] = {"longitude":"108.88" , "latitude":"34.34" };
    //
    // for(var i = 0;i < points.length;i++){
    //     addMarker(points[i]);
    // }
    getPoints();

    //线
    // var lines = new Array();
    // lines[0] = {"longitude":"104.06" , "latitude":"30.5","longitude1":"114.27" , "latitude1":"30.58"};
    // lines[1] = {"longitude":"114.27" , "latitude":"30.58","longitude1":"108.88" , "latitude1":"34.34" };
    // for(var i = 0;i < lines.length;i++){
    //    addLine(lines[i]);
    // }
    getLines();
}

function getPoints() {
    var ret = [];
    $.ajax({
        type : 'POST',
        url : "/point/getall",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            var points = data.points;
            // alert("你查询的数据条数为："+points.length);
            if(points != null && points.length > 0){
                for(var i=0;i < points.length;i++){
                    var point = points[i];
                    if (ret.indexOf(points[i]) === -1) {
                        // ret.push(points[i]);
                        addMarker(point.longitude,point.latitude);
                    }
                }
            }
            // console.log("----------- success-------------" + ret.length);
        },
        error : function(data) {
            alert("加载光缆节点失败");
        }
    });
}

function  getLines() {
    $.ajax({
        type : 'POST',
        url : "/point/getline",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            // console.log(data);
            var lines = data.lines;
            // alert("你查询的数据条数为："+lines.length);
            if (lines != null && lines.length > 0){
                for(var i=0;i < lines.length;i++){
                    var line = lines[i];
                    // console.log(line.before_id);
                    if (line.befor_id != null){//排除掉id为空的情况
                        addLine(line);
                    }
                }
            }
        },
        error : function(data) {
            alert("----------- fail-------------");
        }
    });
}

//添加线路
function addLine(line){
    var lineArr = new Array();//创建线覆盖物节点坐标数组
    // console.log(line.longitude +"----------- success-------------"+line.latitude);
    // console.log(line.befor_longitude +"----------- success-------------"+line.befor_latitude);
    // lineArr.push(new AMap.LngLat("104.066541","30.572269"));
    // lineArr.push(new AMap.LngLat("105.843353","32.435436"));
    lineArr.push(new AMap.LngLat(line.befor_longitude,line.befor_latitude));
    lineArr.push(new AMap.LngLat(line.longitude,line.latitude));
    var polyline = new AMap.Polyline({
        path:lineArr, //设置线覆盖物路径
        strokeColor:"#3366FF", //线颜色
        strokeOpacity:1, //线透明度
        strokeWeight:8, //线宽
        strokeStyle:"solid", //线样式
        strokeDasharray:[10,6], //补充线样式
        showDir : true//显示线上的箭头
    });
    polyline.setMap(map);
}

//清空地图
function clearMap(){
    map.clearMap();
    cloudDataLayer.setMap(null);
}

//标记点图标
var icon = new AMap.Icon({
    image : 'http://vdata.amap.com/icons/b18/1/2.png',//24px*24px
    //icon可缺省，缺省时为默认的蓝色水滴图标，
    size : new AMap.Size(24,24)
});

//实例化marker
function addMarker(longitude,latitude){
    //点标记
    var marker = new AMap.Marker({
        //icon可缺省，缺省时为默认的蓝色水滴图标
        // icon:icon,
        position:new AMap.LngLat(longitude,latitude)
    });
    marker.setMap(map);  //在地图上添加点

    AMap.event.addListener(marker,'click',getLnglat); //点击事件,弹出窗口
}

//鼠标点击，获取经纬度坐标
function getLnglat(e){
    var x = e.lnglat.getLng();
    var y = e.lnglat.getLat();

    //实例化信息窗体
    var content = [];
    content.push("经纬度:" + x + "," + y);

    var infoWindow = new AMap.InfoWindow({
        content: content.join("<br/>"),
        offset: new AMap.Pixel(16, -45)
    });
    //打开窗口
    infoWindow.open(map, new AMap.LngLat(x,y));
}

