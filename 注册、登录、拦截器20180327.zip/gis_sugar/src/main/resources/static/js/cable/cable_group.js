//父组下拉菜单------------
var setting = {
    view: {
        dblClickExpand: false
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    callback: {
        // beforeClick: beforeClick,
        onClick: onClick
    }
};
//数据加载
function createNodes(maxNodesNumInLevel, maxLevel, curLevel, curPId) {
    if (maxNodesNumInLevel<5) {
        maxNodesNumInLevel = 5;
    }
    var nodes = [], num = 0;
    while(num<3) {
        num = parseInt(Math.random()*1024)%maxNodesNumInLevel+1;
    }
    for (var i=0; i<num; i++) {
        var id = curPId ? curPId + "-" + i : "" + i, isParent = (parseInt(Math.random()*9999)%3!=0),
            node = {id: id, pId : curPId, name : "N" + id};
            nodes.push(node);
        if (isParent && curLevel<maxLevel) {
            nodes = nodes.concat(createNodes(maxNodesNumInLevel, maxLevel, curLevel+1, id));
        }
    }
    return nodes;
}
//得到所有的光缆组
function getgroups() {
    var nodes = [];
    $.ajax({
        type : 'POST',
        url : "/group/getall",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            var groups = data.groups;
            // alert("你查询的数据条数为："+groups.length);
            if (groups != null && groups.length > 0){
                for(var i=0;i < groups.length;i++){
                    var group = groups[i];
                    var groupname = group.groupName;
                    if(group.groupDesc != ""){
                        groupname = group.groupDesc;
                    }
                    nodes[i] = {id: group.id, pId : group.extendFieldLong, name : groupname, open:true, icon:"../../img/cable/group.png"};
                }
            }
        },
        error : function(data) {
            alert("刷新光缆组信息失败")
            // console.log("----------- fail-------------");
        }
    });
    return nodes;
}
var zNodes = getgroups();//createNodes(5, 5, 0);

function beforeClick(treeId, treeNode) {
    var check = (treeNode && !treeNode.isParent);
    if (!check) alert("只能选择城市...");
    return check;
}

function onClick(e, treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        nodes = zTree.getSelectedNodes(),
        v = "";
    nodes.sort(function compare(a,b){return a.id-b.id;});
    if (nodes.length > 1) {
        alert("只能选择一个父组");
        return;
    }
    for (var i=0, l=nodes.length; i<l; i++) {
        v += nodes[i].name + ",";
        setPid(nodes[i].id);//给父组赋值

    }
    if (v.length > 0 ) v = v.substring(0, v.length-1);
    var cityObj = $("#parentgroup");
    cityObj.attr("value", v);

}

function setPid(pid) {
    document.getElementById("pid").value = pid;
}

function showMenu() {
    var cityObj = $("#parentgroup");
    var cityOffset = $("#parentgroup").offset();
    $("#menuContent").css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");

    $("body").bind("mousedown", onBodyDown);

    $.fn.zTree.init($("#treeDemo"), setting, zNodes);

    //选中
    selectTree();
    // console.log("----------TREE-------------")
}
function hideMenu() {
    $("#menuContent").fadeOut("fast");
    $("body").unbind("mousedown", onBodyDown);
}
function onBodyDown(event) {
    if (!(event.target.id == "menuBtn" || event.target.id == "menuContent" || $(event.target).parents("#menuContent").length>0)) {
        hideMenu();
    }
}

var pid = 0;
//添加光缆组
function addGroup(){
    var pid = document.getElementById("pid").value;
    var groupName = document.getElementById("groupName").value;
    var groupDesc = document.getElementById("groupDesc").value;
    var parentgroup = document.getElementById("parentgroup").value;
    var district = document.getElementById("district").value;
    var entryUser = document.getElementById("entryUser").value;
    var groupParam = document.getElementById("remarks").value;
    // console.log(parentgroup + "pid-------------" + pid);
    if(groupName == ""){
        alert("名称不能为空");
        return;
    }
    // console.log(judgment(groupName) + "--------------");
    if(judgment(groupName) > 0){//判断名称是否重复
        alert("名称不能重复");
        return;
    }
    if(parentgroup == ""){
        alert("父组不能为空");
        return;
    }
    // console.log("pid-------------" + pid);
    var form = new FormData();
    form.append("pid",pid);
    form.append("groupName",groupName);
    form.append("groupDesc",groupDesc);
    form.append("parentGroup",parentgroup);
    form.append("district",district);
    form.append("entryUser",entryUser);
    form.append("groupParam",groupParam);
    // console.log(form);
    $.ajax({
        url:"/group/add",
        type:"POST",
        data:form,
        processData:false,
        contentType:false,
        async:false,
        success:function(data){
            alert("成功！！");
            refresh();
            window.top.tree.refresh();//刷新左边目录树
            // //提交数据时清空表单中的数据
            $('#form2')[0].reset();
            $("#parentgroup").attr("value", "");
            // console.log("over..");
        },
        error:function(e){
            alert("错误！！");
            window.clearInterval(timer);
        }
    });
}

//修改光缆组
function updateGroup(){
    var id = document.getElementById("id").value;
    var pid = document.getElementById("pid").value;
    var groupName = document.getElementById("groupName").value;
    var groupDesc = document.getElementById("groupDesc").value;
    var parentgroup = document.getElementById("parentgroup").value;
    var district = document.getElementById("district").value;
    var entryUser = document.getElementById("entryUser").value;
    var groupParam = document.getElementById("remarks").value;

    if(parentgroup == groupDesc || parentgroup == groupName){
        alert("父组不能选择节点本身");
        return;
    }
    if(parentgroup == ""  ){
        alert("父组不能为空");
        return;
    }
    var form = new FormData();
    form.append("pid",pid);
    form.append("id",id);
    form.append("groupDesc",groupDesc);
    form.append("parentGroup",parentgroup);
    form.append("district",district);
    form.append("entryUser",entryUser);
    form.append("groupParam",groupParam);
    // console.log("pid-------------" + pid)
    $.ajax({
        url:"/group/update" ,
        type:"POST",
        data:form,
        processData:false,
        contentType:false,
        success:function(data){
            alert("成功！！");
            refresh();
            window.top.tree.refresh();//刷新左边目录树
            // //提交数据时清空表单中的数据
            $('#form2')[0].reset();
            $("#parentgroup").attr("value", "");
        },
        error:function(e){
            alert("错误！！");
        }
    });
}

//刷新光缆列表
function refresh(){
    document.getElementById('form2').style.display='none';//关闭配置界面

    var tree = window.top.tree.zTreeObj;//得到左边目录树
    var nodes = tree.getSelectedNodes();//得到左边目录树的选中
    // console.log(nodes);
    var url = "/group/getall";//默认查询全部告警
    var groupids = new Array();
    if(nodes != null && nodes.length > 0){
        for (var i=0;i<nodes.length; i++) {
            var id = nodes[i].id+'';//转换成字符串，不然纯数字会报错
            if(id.indexOf("W") != -1){//判断是否选中的有节点----W是写死的，代表节点，Q代表光缆
                // alert("请选中光缆组");
                // return;
            }
            if(id.indexOf("Q") != -1){
                // alert("请选中光缆组");
                // return;
            }
            if(checkInteger(id) > 0){//判断是否是纯数字
                groupids.push(id);
            }
        }
        if (groupids != null && groupids.length > 0){//判断是否有选中符合要求的。
            url = "/group/getgroupbyids";
        }
    }
    var form = new FormData();
    form.append("groupids",groupids);
    // console.log(groupids + "-----------");
    // console.log("刷新表格数据，并隐藏添加界面。");
    $.ajax({
        type : 'POST',
        url : url,
        data : form,
        async:false,
        processData:false,
        contentType:false,
        success : function(data) {
            // console.log("----------- success-------------");
            // console.log(data);
            var groups = data.groups;
            var dom = '';
            if (groups != null && groups.length> 0){
                for(var i=0;i < groups.length;i++){
                    var group = groups[i];
                    var p = new Array();
                    p[0] = group.id;
                    p[1] = "'"+group.groupName+"'";
                    p[2] = "'"+group.groupDesc+"'";
                    p[3] = "'"+group.parentGroup+"'";
                    p[4] = "'"+group.district+"'";
                    p[5] = "'"+group.entryUser+"'";
                    p[6] = "'"+group.groupParam+"'";
                    p[7] = group.extendFieldLong;
                    // console.log(p);
                    dom += '<tr>';
                    dom += '<td>'+group.groupName+'</td>';
                    dom += '<td>'+group.groupDesc+'</td>';
                    dom += '<td>'+group.parentGroup+'</td>';
                    dom += '<td>'+group.district+'</td>';
                    dom += '<td>'+group.entryUser+'</td>';
                    dom += '<td>'+group.groupParam+'</td>';
                    if(group.parentGroup == ""){
                        dom += '<td>&nbsp;&nbsp;</td>';
                    }else {
                        dom += '<td>' +
                            '<a href="#" onclick="edit('+p+');" style="background:url(../../img/edit.png) no-repeat;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>' +
                            '&nbsp;&nbsp;<a href="#" onclick="del('+group.id+');" style="background:url(../../img/del.png) no-repeat;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>' +
                            '</td>';
                    }
                    dom += '</tr>';
                }
            }
            $('#group_table').html(dom);
        },
        error : function(data) {
            alert("刷新光缆组信息失败");
        }
    });
    return true;
}

//删除
function del(id){
    if (confirm("确定删除光缆组吗？")) {
        var form = new FormData();
        form.append("id",id);
        $.ajax({
            url: "/group/del",
            type: "POST",
            data: form,
            processData: false,
            contentType: false,
            success: function (data) {
                alert("成功！！");
                refresh();
                window.top.tree.refresh();//刷新左边目录树
                // console.log("over..");
            },
            error: function (e) {
                alert("错误！！");
                // window.clearInterval(timer);
            }
        });
    }
    return true;
}

//修改，赋值
function edit(id,groupName,groupDesc,parentGroup,district,entryUser,groupParam,pid){
    document.getElementById('form2').style.display='';

    document.getElementById("id").value = id;
    document.getElementById("pid").value = pid;
    document.getElementById("groupName").value = groupName;
    document.getElementById("groupDesc").value = groupDesc;
    document.getElementById("district").value = district;
    document.getElementById("entryUser").value = entryUser;
    document.getElementById("remarks").value = groupParam;
        // console.log("parentGroup---------" + parentGroup);
    $("#parentgroup").attr("value", parentGroup);//给父组赋值
    $("#groupName").attr("readOnly",true);// 不可编辑，可以传值
    $("#groupName").css('background-color','#fafbfb');
}

//树结构选中
function selectTree() {
    var id = document.getElementById("pid").value;
    // console.log(id + "++++++++++++++++++");
    if (id != null && id != ''){
        var zTree = $.fn.zTree.getZTreeObj("treeDemo");//treeDemo界面中加载ztree的div
        var node = zTree.getNodeByParam("id",id);
        zTree.cancelSelectedNode();//先取消所有的选中状态
        zTree.selectNode(node,true);//将指定ID的节点选中
        zTree.expandNode(node, true, false);//将指定ID节点展开
    }
}

//点击添加  打开添加的界面，并清空说有数据
function add() {
    document.getElementById('form2').style.display='';//打开添加界面

    $("#groupName").attr("readOnly",false);
    $("#groupName").css('background-color','#FFFFFF');

    $('#form2')[0].reset();
    $("#parentgroup").attr("value", "");
}

//判断用户名是否重复
function judgment(groupname) {
    var num = -1;
    var form = new FormData();
    form.append("groupname",groupname);
    $.ajax({
        url: "/group/getgroupbygroupname",
        type: "POST",
        data: form,
        processData: false,
        contentType: false,
        async:false,
        success: function (data) {
            // console.log(data.group);
            if(data.group != null){
                num = 1;
            }
        },
        error: function (e) {
            // alert("错误！！");
        }
    });
    // console.log("+++++++++++++++++");
    return num;
}