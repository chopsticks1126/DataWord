//父组下拉菜单------------
var setting = {
    view: {
        dblClickExpand: false
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    callback: {
        beforeClick: beforeClick,
        onClick: onClick
    }
};
//数据加载
function createNodes(maxNodesNumInLevel, maxLevel, curLevel, curPId) {
    if (maxNodesNumInLevel<5) {
        maxNodesNumInLevel = 5;
    }
    var nodes = [], num = 0;
    while(num<3) {
        num = parseInt(Math.random()*1024)%maxNodesNumInLevel+1;
    }
    for (var i=0; i<num; i++) {
        var id = curPId ? curPId + "-" + i : "" + i, isParent = (parseInt(Math.random()*9999)%3!=0),
            node = {id: id, pId : curPId, name : "N" + id};
        nodes.push(node);
        if (isParent && curLevel<maxLevel) {
            nodes = nodes.concat(createNodes(maxNodesNumInLevel, maxLevel, curLevel+1, id));
        }
    }
    return nodes;
}

//得到所有的光缆+光缆信息
function getgroupsandcables() {
    var nodes = [];
    var i_max = 0;
    $.ajax({
        type : 'POST',
        url : "/group/getall",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            var groups = data.groups;
            // alert("你查询的数据条数为："+groups.length);
            if(groups != null && groups.length > 0){
                i_max  = groups.length;
                for(var i=0;i < i_max;i++){
                    var group = groups[i];
                    var groupname = group.groupName;
                    if(group.groupDesc != ""){
                        groupname = group.groupDesc;
                    }
                    nodes[i] = {id: group.id, pId : group.extendFieldLong, name : groupname, open:true, icon:"../../img/cable/group.png"};
                }
            }
        },
        error : function(data) {
            // console.log("----------- fail-------------");
        }
    });
    // console.log(nodes);
    $.ajax({
        type : 'POST',
        url : "/cable/getall",
        async:false,
        success : function(data) {
            // console.log("----------- success-------------");
            var cables = data.cables;
            // alert("你查询的数据条数为："+groups.length);
            if(cables != null && cables.length > 0){
                for(var i=i_max;i < cables.length+i_max;i++){
                    var cable = cables[i-i_max];
                    // console.log(cable);
                    var cableName = cable.cableName;
                    if(cable.cableDesc != ""){
                        cableName = cable.cableDesc;
                    }
                    nodes[i] = {id: cable.id+"Q", pId : cable.groupid, name : cableName, open:true, icon:"../../img/cable/cable.png"};
                }
            }
        },
        error : function(data) {
            // console.log("----------- fail-------------");
        }
    });
    // console.log(nodes);
    return nodes;
}

var zNodes = getgroupsandcables();//createNodes(5, 5, 0);

function beforeClick(treeId, treeNode) {
    var check = (treeNode && !treeNode.isParent);
    if (!check) alert("只能选中光缆");
    return check;
}

function onClick(e, treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        nodes = zTree.getSelectedNodes(),
        v = "";
    nodes.sort(function compare(a,b){return a.id-b.id;});
    if (nodes.length > 1) {
        alert("只能选择一个父组");
        return;
    }
    for (var i=0, l=nodes.length; i<l; i++) {
        v += nodes[i].name + ",";

        var cableid = nodes[i].id;
        if(cableid.length > 0){
            cableid = cableid.substring(0,cableid.length-1);//去掉之前加的Q
        }
        document.getElementById("cableid").value = cableid;
    }
    if (v.length > 0 ) v = v.substring(0, v.length-1);
    var cityObj = $("#parentgroup");
    cityObj.attr("value", v);

    getPointsByCableId();//选中父组后加载前节点
}

function showMenuByCableId() {
    var cityObj = $("#parentgroup");
    var cityOffset = $("#parentgroup").offset();
    $("#menuContent").css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");
    $("body").bind("mousedown", onBodyDown);

    $.fn.zTree.init($("#treeDemo"), setting, zNodes);

    selectTree();//选中
}
function hideMenu() {
    $("#menuContent").fadeOut("fast");
    $("body").unbind("mousedown", onBodyDown);
}
function onBodyDown(event) {
    if (!(event.target.id == "menuBtn" || event.target.id == "menuContent" || $(event.target).parents("#menuContent").length>0)) {
        hideMenu();
    }
}

function getPointsByCableId() {
    $("#beforepoval").find("option").remove();//清空下拉选项

    var form = new FormData();
    var cableid = document.getElementById("cableid").value;

    if (cableid == ""){
        alert("请选择所属光缆");
        return;
    }
    // console.log(cableid);
    form.append("cableid",cableid);
    $.ajax({
        url : '/point/getpointbycableid ',
        type : 'POST',
        data : form,
        processData:false,
        contentType:false,
        async:false,//设置是否异步，会影响方法执行顺序
        success : function(data) {
            // console.log("----------- success------11111111-------");
            // console.log(data);
            setSelectByBeforePoint(0,"");//默认加一个置空
            var points = data.points;
            for(var i=0;i < points.length;i++){
                var point = points[i];
                var pointName = point.pointName;
                if(point.pointDesc != ""){
                    pointName = point.pointDesc;
                }
                setSelectByBeforePoint(point.id,pointName);
            }
        },
        error : function(data) {
            alert("加载前节点数据失败");
            // console.log("----------- fail-------------");
        }
    });
}

//为Select追加一个Option(下拉项)
function setSelectByBeforePoint(id,pointName) {
    $("#beforepoval").append('<option value='+id+'>'+pointName+'</option>');
}

function addPoint(){
    var cableid = document.getElementById("cableid").value;
    var pointName = document.getElementById("pointName").value;
    var pointDesc = document.getElementById("pointDesc").value;
    var parentgroup = document.getElementById("parentgroup").value;
    var district = document.getElementById("district").value;
    var longitude = document.getElementById("longitude").value;
    var latitude = document.getElementById("latitude").value;

    // var beforepoid = document.getElementById("beforepoid").value;
    var beforepoid =  $("#beforepoval option:selected").val();
    var beforepoval = document.getElementById("beforepoval").value;

    var distance = document.getElementById("distance").value;
    var remarks = document.getElementById("remarks").value;

    // console.log(beforepoval + "----------++++");
    if(pointName == ""  ){
        alert("名称不能为空");
        return;
    }
    if(parentgroup == ""  ){
        alert("父组不能为空");
        return;
    }

    if(distance == ""  ){
        alert("距离不能为空");
        return;
    }
    var form = new FormData();
    form.append("cableid",cableid);
    form.append("pointName",pointName);
    form.append("pointDesc",pointDesc);
    form.append("cableName",parentgroup);
    form.append("longitude",longitude);
    form.append("latitude",latitude);
    if(beforepoval != null && beforepoval != ""){
        form.append("beforepointid",beforepoid);
        form.append("extendFieldString",beforepoval);
    }else{
        form.append("beforepointid",0);
        form.append("extendFieldString","");
    }

    form.append("distance",distance);
    form.append("pointParam",remarks);
    // console.log(form);
    // console.log(beforepoid);
    // console.log(cableid);
    $.ajax({
        url:"/point/add",
        type:"POST",
        data:form,
        processData:false,
        contentType:false,
        success:function(data){
            alert("成功！！");
            refresh();
            $('#cablepoint_from')[0].reset();
            $("#parentgroup").attr("value", "");//树结构input清空
            $("#beforepoval").find("option").remove();//清空下拉选项
            window.top.tree.refresh();//刷新左边目录树
        },
        error:function(e){
            alert("错误！！");
        }
    });
}

function updatePoint(){
    var id = document.getElementById("id").value;
    var cableid = document.getElementById("cableid").value;
    // var pointName = document.getElementById("pointName").value;
    var pointDesc = document.getElementById("pointDesc").value;
    var parentgroup = document.getElementById("parentgroup").value;
    var district = document.getElementById("district").value;
    var longitude = document.getElementById("longitude").value;
    var latitude = document.getElementById("latitude").value;

    var beforepoid =  $("#beforepoval option:selected").val();
    var beforepoval = document.getElementById("beforepoval").value;

    var distance = document.getElementById("distance").value;
    var remarks = document.getElementById("remarks").value;
    // console.log(beforepoval + "----------++++");
    if(parentgroup == ""  ){
        alert("父组不能为空");
        return;
    }

    if(distance == ""  ){
        alert("距离不能为空");
        return;
    }
    var form = new FormData();
    form.append("id",id);
    form.append("pointDesc",pointDesc);
    form.append("longitude",longitude);
    form.append("latitude",latitude);
    if(beforepoval != null && beforepoval != ""){
        form.append("beforepointid",beforepoid);
        form.append("extendFieldString",beforepoval);
    }else{
        form.append("beforepointid",0);
        form.append("extendFieldString","");
    }
    form.append("distance",distance);
    form.append("cableid",cableid);
    form.append("cableName",parentgroup);
    form.append("pointParam",remarks);
    // console.log(form);
    $.ajax({
        url:"/point/update",
        type:"POST",
        data:form,
        processData:false,
        contentType:false,
        success:function(data){
            alert("成功！！");
            refresh();
            $('#cablepoint_from')[0].reset();
            $("#parentgroup").attr("value", "");//树结构input清空
            $("#beforepoval").find("option").remove();//清空下拉选项
            window.top.tree.refresh();//刷新左边目录树
        },
        error:function(e){
            alert("错误！！");
        }
    });
}

function del(id){
    if (confirm("确定删除光缆节点吗？")) {
        var form = new FormData();
        form.append("id",id);
        $.ajax({
            url: "/point/del",
            type: "POST",
            data: form,
            processData: false,
            contentType: false,
            success: function (data) {
                alert("成功！！");
                refresh();
                window.top.tree.refresh();//刷新左边目录树
            },
            error: function (e) {
                alert("错误！！");
            }
        });
    }
}

function refresh(){
    document.getElementById('cablepoint_from').style.display='none';//默认隐藏添加界面
    var tree = window.top.tree.zTreeObj;//得到左边目录树
    var nodes = tree.getSelectedNodes();//得到左边目录树的选中
    // console.log(nodes);
    var url = "/point/getall";//默认查询全部节点
    var groupids = new Array();
    var cableids = new Array();
    var pointids = new Array();
    if(nodes != null && nodes.length > 0){
        for (var i=0;i<nodes.length; i++) {
            var id = nodes[i].id+'';//转换成字符串，不然纯数字会报错
            if(id.indexOf("W") != -1){//判断是否选中的有节点----W是写死的，代表节点，Q代表光缆
                pointids.push(id.substring(0,id.length-1));
            }
            if(id.indexOf("Q") != -1){
                cableids.push(id.substring(0,id.length-1));
            }
            if(checkInteger(id) > 0){//判断是否是纯数字
                groupids.push(id);
            }
        }
        if ((groupids != null && groupids.length > 0) || (cableids != null && cableids.length > 0)
                    || (pointids != null && pointids.length > 0)){//判断是否有选中符合要求的。
            url = "/point/getpointbyids";
        }
    }
    var form = new FormData();
    form.append("groupids",groupids);
    form.append("cableids",cableids);
    form.append("pointids",pointids);
    console.log(pointids);
    $.ajax({
        type : 'POST',
        url : url,
        data : form,
        async:false,
        processData:false,
        contentType:false,
        success : function(data) {
            console.log(data);
            // console.log("----------- success-------------");
            var points = data.points;
            var dom = '';
            if(points != null && points.length > 0){
                for(var i=0;i < points.length;i++){
                    var point = points[i];
                    var p = new Array();
                    p[0] = point.id;
                    p[1] = "'"+point.pointName+"'";
                    p[2] = "'"+point.pointDesc+"'";
                    p[3] = point.cableid;
                    p[4] = "'"+point.cableName+"'";
                    p[5] = point.longitude;
                    p[6] = point.latitude;
                    p[7] = point.beforepointid;
                    p[8] = point.distance;
                    p[9] = "'"+point.pointParam+"'";

                    // console.log(p);
                    var beforePoint = point.beforepointid>0?point.extendFieldString:"";

                    dom += '<tr>';
                    dom += '<td>'+point.pointName+'</td>';
                    dom += '<td>'+point.pointDesc+'</td>';
                    dom += '<td>'+point.cableName+'</td>';
                    dom += '<td>'+point.longitude + '-' + point.latitude +'</td>';
                    dom += '<td>'+beforePoint+'</td>';
                    dom += '<td>'+point.distance+'</td>';
                    dom += '<td>'+point.pointParam+'</td>';
                    dom += '<td>' +
                        '<a href="#" onclick="edit('+p+');" style="background:url(../../img/edit.png) no-repeat;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>' +
                        '&nbsp;&nbsp;<a href="#" onclick="del('+point.id+');" style="background:url(../../img/del.png) no-repeat;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>' +
                        '</td>';
                    dom += '</tr>';
                }
            }
            $('#point_table').html(dom);
        },
        error : function(data) {
            alert("刷新数据失败");
        }
    });
}

function edit(id,pointName,pointDesc,cableid,cableName,longitude,latitude,beforepointid,distance,pointParam){
    document.getElementById('cablepoint_from').style.display='';
    document.getElementById("id").value=id;
    document.getElementById("cableid").value=cableid;
    document.getElementById("pointName").value=pointName;
    document.getElementById("pointDesc").value=pointDesc;
    document.getElementById("parentgroup").value=cableName;

    getDistrict(longitude,latitude);//根据经纬度得到地名

    document.getElementById("longitude").value=longitude;
    document.getElementById("latitude").value=latitude;
    document.getElementById("distance").value=distance;
    document.getElementById("remarks").value=pointParam;

    $("#pointName").attr("readOnly",true);// 不可编辑，可以传值
    $("#pointName").css('background-color','#fafbfb');

    getPointsByCableId();//初始化下拉列表前节点
    selectedBybeforPoint(beforepointid);//选中
}

//选中
function selectedBybeforPoint(beforepointid) {
    // console.log("--------------选中---------");
    $("#beforepoval option[value='"+beforepointid+"']").attr("selected","selected");
}

function add() {
    document.getElementById('cablepoint_from').style.display='';

    $('#cablepoint_from')[0].reset();
    $("#parentgroup").attr("value", "");//树结构input清空
    $("#beforepoval").find("option").remove();//清空下拉选项

    $("#pointName").attr("readOnly",false);
    $("#pointName").css('background-color','#FFFFFF');
}

//树结构选中
function selectTree() {
    var id = document.getElementById("cableid").value;
    // console.log(id + "++++++++++++++++++");
    if (id != null && id != ''){
        var zTree = $.fn.zTree.getZTreeObj("treeDemo");//treeDemo界面中加载ztree的div
        var node = zTree.getNodeByParam("id",id);
        zTree.cancelSelectedNode();//先取消所有的选中状态
        zTree.selectNode(node,true);//将指定ID的节点选中
        zTree.expandNode(node, true, false);//将指定ID节点展开
    }
}

//根据地名得到经纬度
var myGeo;
function getCoordinate() {
    var district = document.getElementById("district").value;

    if (myGeo == null){
        myGeo = new AMap.Geocoder();
    }
    //地理编码,返回地理编码结果
    // console.log("district..." + district);
    myGeo.getLocation(district, function(status, result) {
        // console.log("status----------" + status);
        if (status === 'complete' && result.info === 'OK') {
            //地址解析成功
            geocoder_CallBack(result);
        }
        else{
            //地址解析失败
            console.log("地址解析失败...");
        }
    });
}

//地理编码返回结果展示
function geocoder_CallBack(data) {
    var geocode = data.geocodes;
    // console.log("point："+geocode[0].location.getLng() + "---" + geocode[0].location.getLat() );
    document.getElementById("longitude").value=geocode[0].location.getLng();
    document.getElementById("latitude").value=geocode[0].location.getLat();
}

//根据经纬度获取地理名称
function getDistrict(longitude,latitude) {
    var lnglatXY=[longitude, latitude];//地图上所标点的坐标
    if (myGeo == null){
        myGeo = new AMap.Geocoder();
    }
    myGeo.getAddress(lnglatXY, function(status, result) {
        // console.log("status---1111-------" + status);
        console.log("result.info---1111-------" + result.info);
        if (status === 'complete' && result.info === 'OK') {
            //获得了有效的地址信息:
            // console.log(result);
            // console.log(result.regeocode.formattedAddress);
            geoName_CallBack(result);

        }
    });
}

//地理名称返回结果展示
function geoName_CallBack(data) {
    var regeocode = data.regeocode;
    document.getElementById("district").value = regeocode.formattedAddress
}