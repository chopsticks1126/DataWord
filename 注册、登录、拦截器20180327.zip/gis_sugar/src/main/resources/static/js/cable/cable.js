//父组下拉菜单------------
var setting = {
    view: {
        dblClickExpand: false
    },
    data: {
        simpleData: {
            enable: true
        }
    },
    callback: {
        // beforeClick: beforeClick,
        onClick: onClick
    }
};
//数据加载--测试数据
function createNodes(maxNodesNumInLevel, maxLevel, curLevel, curPId) {
    if (maxNodesNumInLevel<5) {
        maxNodesNumInLevel = 5;
    }
    var nodes = [], num = 0;
    while(num<3) {
        num = parseInt(Math.random()*1024)%maxNodesNumInLevel+1;
    }
    for (var i=0; i<num; i++) {
        var id = curPId ? curPId + "-" + i : "" + i, isParent = (parseInt(Math.random()*9999)%3!=0),
            node = {id: id, pId : curPId, name : "N" + id};
        nodes.push(node);
        if (isParent && curLevel<maxLevel) {
            nodes = nodes.concat(createNodes(maxNodesNumInLevel, maxLevel, curLevel+1, id));
        }
    }
    return nodes;
}
//得到所有的光缆组信息
function getgroups() {
    var nodes = [];
    $.ajax({
        type : 'POST',
        url : "/cable/getall",
        async:false,
        success : function(data) {
            console.log("----------- success-------------");
            var groups = data.groups;
            // alert("你查询的数据条数为："+groups.length);
            if(groups != null && groups.length > 0){
                for(var i=0;i < groups.length;i++){
                    var group = groups[i];
                    var groupname = group.groupName;
                    if(group.groupDesc != ""){
                        groupname = group.groupDesc;
                    }
                    nodes[i] = {id: group.id, pId : group.extendFieldLong, name : groupname, open:true, icon:"../../img/cable/group.png"};
                }
            }

        },
        error : function(data) {
            console.log("----------- fail-------------");
        }
    });
    return nodes;
}
var zNodes = getgroups();//createNodes(5, 5, 0);

function beforeClick(treeId, treeNode) {
    var check = (treeNode && !treeNode.isParent);
    if (!check) alert("只能选择城市...");
    return check;
}

function onClick(e, treeId, treeNode) {
    var zTree = $.fn.zTree.getZTreeObj("treeDemo"),
        nodes = zTree.getSelectedNodes(),
        v = "";
    nodes.sort(function compare(a,b){return a.id-b.id;});
    if (nodes.length > 1) {
        alert("只能选择一个父组");
        return;
    }
    for (var i=0, l=nodes.length; i<l; i++) {
        v += nodes[i].name + ",";
        document.getElementById("groupid").value = nodes[i].id;//选中的父组给父组ID复制
    }
    if (v.length > 0 ) v = v.substring(0, v.length-1);
    var cityObj = $("#parentgroup");
    cityObj.attr("value", v);
}

function showMenu() {
    var cityObj = $("#parentgroup");
    var cityOffset = $("#parentgroup").offset();
    $("#menuContent").css({left:cityOffset.left + "px", top:cityOffset.top + cityObj.outerHeight() + "px"}).slideDown("fast");

    $("body").bind("mousedown", onBodyDown);

    $.fn.zTree.init($("#treeDemo"), setting, zNodes);

    selectTree();//选中
}
function hideMenu() {
    $("#menuContent").fadeOut("fast");
    $("body").unbind("mousedown", onBodyDown);
}
function onBodyDown(event) {
    if (!(event.target.id == "menuBtn" || event.target.id == "menuContent" || $(event.target).parents("#menuContent").length>0)) {
        hideMenu();
    }
}

//判断名称是否重复
function judgment(cableName) {
    var num = -1;
    var form = new FormData();
    form.append("cableName",cableName);
    $.ajax({
        url: "/cable/getcablebycablename",
        type: "POST",
        data: form,
        processData: false,
        contentType: false,
        async:false,
        success: function (data) {
            if(data.cable != null){
                num = 1;
            }
        },
        error: function (e) {
        }
    });
    return num;
}

//添加光缆
function addCable(){
    var groupid = document.getElementById("groupid").value;
    var cableName = document.getElementById("cableName").value;
    var cableDesc = document.getElementById("cableDesc").value;
    var parentgroup = document.getElementById("parentgroup").value;
    var cableNum = document.getElementById("cableNum").value;
    var cableCode = document.getElementById("cableCode").value;
    var reservedCode = document.getElementById("reservedCode").value;

    var distance = document.getElementById("distance").value;
    var coreNum = document.getElementById("coreNum").value;
    var startPoint = document.getElementById("startPoint").value;
    var endPoint = document.getElementById("endPoint").value;
    var manufacturer = document.getElementById("manufacturer").value;
    var item = document.getElementById("item").value;
    var remarks = document.getElementById("remarks").value;

    if(cableName == ""  ){
        alert("名称不能为空");
        return;
    }
    if (judgment(cableName) > 0){
        alert("名称不能重复");
        return;
    }
    if(parentgroup == ""  ){
        alert("父组不能为空");
        return;
    }
    if(distance == ""){
        alert("距离不能为空");
        return;
    }
    if(startPoint == ""  ){
        alert("始端不能为空");
        return;
    }
    if(endPoint == ""  ){
        alert("终端不能为空");
        return;
    }

    var form = new FormData();
    form.append("groupid",groupid);
    form.append("cableName",cableName);
    form.append("cableDesc",cableDesc);
    form.append("extendFieldString",parentgroup);
    form.append("cableNumber",cableNum);
    form.append("cableCode",cableCode);
    form.append("reservedCode",reservedCode);
    form.append("distance",distance);
    form.append("coreNumber",coreNum);

    form.append("startPoint",startPoint);
    form.append("endPoint",endPoint);
    form.append("manufacturer",manufacturer);
    form.append("item",item);
    form.append("cableParam",remarks);
    // console.log(form);
    // console.log(groupid);
    $.ajax({
        url:"/cable/add",
        type:"POST",
        data:form,
        processData:false,
        contentType:false,
        async:false,
        success:function(data){
            alert("成功！！");
            //刷新表格
            refresh();
            //提交数据时清空表单中的数据
            $('#cableconf_from')[0].reset();
            $("#parentgroup").attr("value", "");
            window.top.tree.refresh();//刷新左边目录树
        },
        error:function(e){
            alert("错误！！");
        }
    });
}


//修改光缆
function updateCable(){

    // var cableName = document.getElementById("cableName").value;
    var id = document.getElementById("id").value;
    var groupid = document.getElementById("groupid").value;
    var cableDesc = document.getElementById("cableDesc").value;
    var parentgroup = document.getElementById("parentgroup").value;
    var cableNum = document.getElementById("cableNum").value;
    var cableCode = document.getElementById("cableCode").value;
    var reservedCode = document.getElementById("reservedCode").value;

    var distance = document.getElementById("distance").value;
    var coreNum = document.getElementById("coreNum").value;
    var startPoint = document.getElementById("startPoint").value;
    var endPoint = document.getElementById("endPoint").value;
    var manufacturer = document.getElementById("manufacturer").value;
    var item = document.getElementById("item").value;
    var remarks = document.getElementById("remarks").value;

    if(parentgroup == ""  ){
        alert("父组不能为空");
        return;
    }
    if(distance == ""  ){
        alert("距离不能为空");
        return;
    }
    if(startPoint == ""  ){
        alert("始端不能为空");
        return;
    }
    if(endPoint == ""  ){
        alert("终端不能为空");
        return;
    }

    var form = new FormData();
    form.append("id",id);
    form.append("groupid",groupid);
    // form.append("cableName",cableName);
    form.append("cableDesc",cableDesc);
    form.append("extendFieldString",parentgroup);
    form.append("cableNumber",cableNum);
    form.append("cableCode",cableCode);
    form.append("reservedCode",reservedCode);
    form.append("distance",distance);
    form.append("coreNumber",coreNum);

    form.append("startPoint",startPoint);
    form.append("endPoint",endPoint);
    form.append("manufacturer",manufacturer);
    form.append("item",item);
    form.append("cableParam",remarks);
    console.log(form);
    console.log(groupid);
    $.ajax({
        url:"/cable/update",
        type:"POST",
        data:form,
        processData:false,
        contentType:false,
        success:function(data){
            alert("成功！！");
            //刷新表格
            refresh();
            //提交数据时清空表单中的数据
            $('#cableconf_from')[0].reset();
            $("#parentgroup").attr("value", "");
            window.top.tree.refresh();//刷新左边目录树
        },
        error:function(e){
            alert("错误！！");
        }
    });
}

//删除
function del(id){
    if (confirm("确定删除光缆吗？")) {
        var form = new FormData();
        form.append("id",id);
        $.ajax({
            url: "/cable/delete",
            type: "POST",
            data: form,
            processData: false,
            contentType: false,
            success: function (data) {
                alert("成功！！");
                refresh();
                window.top.tree.refresh();//刷新左边目录树
            },
            error: function (e) {
                alert("错误！！");
            }
        });
    }
}


//刷新光缆列表
function refresh(){
    document.getElementById('cableconf_from').style.display='none';//关闭配置界面
    // console.log("刷新表格数据，并隐藏添加界面。")
    var tree = window.top.tree.zTreeObj;//得到左边目录树
    var nodes = tree.getSelectedNodes();//得到左边目录树的选中
    // console.log(nodes);
    var url = "/cable/getall";//默认查询全部告警
    var groupids = new Array();
    var cableids = new Array();
    if(nodes != null && nodes.length > 0){
        for (var i=0;i<nodes.length; i++) {
            var id = nodes[i].id+'';//转换成字符串，不然纯数字会报错
            if(id.indexOf("W") != -1){//判断是否选中的有节点----W是写死的，代表节点，Q代表光缆
                // alert("请选中光缆组");
                // return;
            }
            if(id.indexOf("Q") != -1){
                cableids.push(id.substring(0,id.length-1));
            }

            if(checkInteger(id) > 0){//判断是否是纯数字
                groupids.push(id);
            }
        }
        if ((groupids != null && groupids.length > 0) || (cableids != null && cableids.length > 0)){//判断是否有选中符合要求的。
            url = "/cable/getcablebyids";
        }
    }
    var form = new FormData();
    form.append("groupids",groupids);
    form.append("cableids",cableids);

    $.ajax({
        type : 'POST',
        url : url,
        data : form,
        async:false,
        processData:false,
        contentType:false,
        success : function(data) {
            // console.log("----------- success-------------");
            console.log(data);
            var cables = data.cables;
            var dom = '';
            if (cables != null && cables.length > 0){
                for(var i=0;i < cables.length;i++){
                    var cable = cables[i];
                    var p = new Array();
                    p[0] = cable.id;
                    p[1] = "'"+cable.cableName+"'";
                    p[2] = "'"+cable.cableDesc+"'";
                    p[3] = "'"+cable.extendFieldString+"'";
                    p[4] = "'"+cable.startPoint+"'";
                    p[5] = "'"+cable.endPoint+"'";
                    p[6] = "'"+cable.distance+"'";
                    p[7] = cable.groupid;

                    p[8] = cable.cableNumber;
                    p[9] = "'"+cable.cableCode+"'";
                    p[10] = "'"+cable.reservedCode+"'";
                    p[11] = "'"+cable.coreNumber+"'";
                    p[12] = "'"+cable.manufacturer+"'";
                    p[13] = "'"+cable.item+"'";
                    p[14] = "'"+cable.cableParam+"'";

                    // console.log(p);
                    dom += '<tr>';
                    dom += '<td>'+cable.cableName+'</td>';
                    dom += '<td>'+cable.cableDesc+'</td>';
                    dom += '<td>'+cable.extendFieldString+'</td>';
                    dom += '<td>'+cable.startPoint + '-' + cable.endPoint +'</td>';
                    dom += '<td>'+cable.distance+'</td>';
                    dom += '<td>'+cable.cableNumber+'</td>';

                    dom += '<td>'+cable.cableCode+'</td>';
                    dom += '<td>'+cable.reservedCode+'</td>';
                    dom += '<td>'+cable.coreNumber+'</td>';
                    dom += '<td>'+cable.manufacturer+'</td>';
                    dom += '<td>'+cable.item+'</td>';
                    dom += '<td>'+cable.cableParam+'</td>';
                    dom += '<td>' +
                        '<a href="#" onclick="edit('+p+');" style="background:url(../../img/edit.png) no-repeat;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>' +
                        '&nbsp;&nbsp;<a href="#" onclick="del('+cable.id+');" style="background:url(../../img/del.png) no-repeat;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>' +
                        '</td>';
                    dom += '</tr>';
                }
            }
            $('#cable_table').html(dom);
        },
        error : function(data) {
            alert("刷新数据失败");
        }
    });
}

//添加清空表单数据
function add(){
    document.getElementById('cableconf_from').style.display='';
    $('#cableconf_from')[0].reset();
    $("#parentgroup").attr("value", "");
    $("#cableName").attr("readOnly",false);
    $("#cableName").css('background-color','#FFFFFF');
}

//修改赋值
function edit(id,cableName,cableDesc,extendFieldString,startPoint,endPoint,
              distance,groupid,cableNumber,cableCode,reservedCode,coreNumber,manufacturer,item,cableParam){
    document.getElementById('cableconf_from').style.display='';

    document.getElementById("id").value = id;
    document.getElementById("groupid").value = groupid;
    document.getElementById("cableName").value = cableName;
    document.getElementById("cableDesc").value = cableDesc;
    // document.getElementById("parentgroup").value = extendFieldString;
    $("#parentgroup").attr("value", extendFieldString);
    document.getElementById("cableNum").value = cableNumber;
    document.getElementById("cableCode").value = cableName;
    document.getElementById("reservedCode").value = reservedCode;

    document.getElementById("distance").value = distance;
    document.getElementById("coreNum").value = coreNumber;
    document.getElementById("startPoint").value = startPoint;
    document.getElementById("endPoint").value = endPoint;
    document.getElementById("manufacturer").value = manufacturer;
    document.getElementById("item").value = item;
    document.getElementById("remarks").value = cableParam;

    $("#cableName").attr("readOnly",true);// 不可编辑，可以传值

    $("#cableName").css('background-color','#fafbfb');
}

//树结构选中
function selectTree() {
    var id = document.getElementById("groupid").value;
    // console.log(id + "++++++++++++++++++");
    if (id != null && id != ''){
        var zTree = $.fn.zTree.getZTreeObj("treeDemo");//treeDemo界面中加载ztree的div
        var node = zTree.getNodeByParam("id",id);
        zTree.cancelSelectedNode();//先取消所有的选中状态
        zTree.selectNode(node,true);//将指定ID的节点选中
        zTree.expandNode(node, true, false);//将指定ID节点展开
    }
}
