function del(id){
    if (confirm("确定删除光缆告警吗？")) {
        var form = new FormData();
        form.append("id",id);
        $.ajax({
            url: "/alarm/del",
            type: "POST",
            data: form,
            processData: false,
            contentType: false,
            success: function (data) {
                alert("成功！！");
                refresh();
            },
            error: function (e) {
                alert("错误！！");
            }
        });
    }
}

function refresh(){
    var tree = window.top.tree.zTreeObj;//得到左边目录树
    var nodes = tree.getSelectedNodes();//得到左边目录树的选中
    // console.log(nodes);
    var url = "/alarm/getall";//默认查询全部告警
    var cableids = new Array();
    var groupids = new Array();
    if(nodes != null && nodes.length > 0){
        for (var i=0;i<nodes.length; i++) {
            var id = nodes[i].id+'';//转换成字符串，不然纯数字会报错
            if(id.indexOf("W") != -1){//判断是否选中的有节点----W是写死的，代表节点，Q代表光缆
                // pointids.push(id.substring(0,id.length-1));
            }
            if(id.indexOf("Q") != -1){
                cableids.push(id.substring(0,id.length-1));
            }
            if(checkInteger(id) > 0){//判断是否是纯数字
                groupids.push(id);
            }
        }
        if ((groupids != null && groupids.length > 0) || (cableids != null && cableids.length > 0)){//判断是否有选中符合要求的。
            url = "/alarm/getalarmbyids";
        }
    }
    var form = new FormData();
    form.append("groupids",groupids);
    form.append("cableids",cableids);

    // console.log(groupids+"--------------");
    // console.log(cableids+"--------------");
    $.ajax({
        type : 'POST',
        url : url,
        data : form,
        async:false,
        processData:false,
        contentType:false,
        success : function(data) {
            console.log(data);
            // console.log("----------- success-------------");
            var alarms = data.alarms;
            var dom = '';
            for(var i=0;i < alarms.length;i++){
                var alarm = alarms[i];
                // console.log(p);
                dom += '<tr>';
                dom += '<td>'+'<input type="checkbox" name="index" value="'+alarm.id+'"/>'+'</td>';
                dom += '<td>'+alarm.nodename+'</td>';
                dom += '<td>'+alarm.nodeip+'</td>';
                dom += '<td>'+alarm.nodetype+'</td>';
                dom += '<td>'+alarm.cablename+'</td>';
                dom += '<td>'+alarm.alarmtype+'</td>';
                dom += '<td>'+alarm.alarmreason+'</td>';
                dom += '<td>'+alarm.alarmcontent+'</td>';
                dom += '<td>'+getCableStatusString(alarm.alarmlever)+'</td>';
                dom += '<td>'+alarm.alarmtime+'</td>';
                dom += '<td>' +
                    '<a href="#" onclick="del('+alarm.id+');" style="background:url(../../img/del.png) no-repeat;text-decoration:none">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>' +
                    '</td>';
                dom += '</tr>';
            }
            $('#alarm_table').html(dom);
        },
        error : function(data) {
            alert("刷新告警数据失败");
        }
    });
}

//状态转换为文字
function getCableStatusString(alarmlever){
    var str = alarmlever;
    // if(alarmlever==0){//开始
    //     str = "0";
    // }else
    if(alarmlever==1){
        str = "正常";
    }
    //新增类型修改
    else if(alarmlever==10){
        str = "变化_严重";
    }else if(alarmlever==7){
        str = "变化_主要";
    }else if(alarmlever==6){
        str = "变化_次要";
    }else if(alarmlever==11){
        str = "新增_严重";
    }else if(alarmlever==9){
        str = "新增_主要";
    }else if(alarmlever==8){
        str = "新增_次要";
    }
    else if(alarmlever==4){
        str = "消失";
    }else if(alarmlever==3){
        str = "新增_不确定";
    }else if(alarmlever==5){
        str = "消失_不确定";
    }
    // else if(alarmlever == 98){
    //     str = "手动恢复";
    // }else if(alarmlever==99){
    //     str = "手动启动";
    // }
    return str;
}

//全选
function selectAll(){
    var obj = document.getElementsByName('index');
    var checked = document.getElementById("allselect").checked;
    for(var i=0;i<obj.length;i++){
        obj.item(i).checked=checked;
    }
}

function delselect(){
    if (confirm("确定删除选中的光缆告警吗？")) {
        var form = new FormData();
        var ids = new Array();
        var obj = document.getElementsByName("index");
        for(var i=0;i<obj.length;i++){
            if(obj[i].checked && obj[i].value > 0) {
                ids.push(obj[i].value);
            }
        }
        console.log(ids);
        form.append("ids",ids);
        $.ajax({
            url: "/alarm/dels",
            type: "POST",
            data: form,
            processData: false,
            contentType: false,
            success: function (data) {
                alert("成功！！");
                refresh();
            },
            error: function (e) {
                alert("错误！！");
            }
        });
    }
}