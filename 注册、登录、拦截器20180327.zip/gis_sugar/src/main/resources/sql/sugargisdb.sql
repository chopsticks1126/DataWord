/*
Navicat MySQL Data Transfer

Source Server         : localhost_33066
Source Server Version : 50614
Source Host           : localhost:33066
Source Database       : ophylinkgisdb

Target Server Type    : MYSQL
Target Server Version : 50614
File Encoding         : 65001

Date: 2018-03-05 11:06:11
*/

/*!40101 SET NAMES gb2312 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sugargis` /*!40100 DEFAULT CHARACTER SET gb2312 */;

USE `sugargis`;

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cablegroup
-- ----------------------------
DROP TABLE IF EXISTS `cablegroup`;
CREATE TABLE `cablegroup` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupName` varchar(64) NOT NULL,
  `groupDesc` varchar(255) DEFAULT NULL,
  `parentGroup` varchar(64) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `principal` varchar(255) DEFAULT NULL,
  `entryTime` timestamp DEFAULT NULL DEFAULT '2011-01-01 08:00:00',
  `entryUser` varchar(255) DEFAULT NULL,
  `updateTime` timestamp DEFAULT NULL DEFAULT '2011-01-01 08:00:00',
  `UpdateUser` varchar(255) DEFAULT NULL,
  `groupImageFile` varchar(64) DEFAULT NULL,
  `groupBackgroundImagefile` varchar(64) DEFAULT NULL,
  `netMask` varchar(255) DEFAULT NULL,
  `groupParam` varchar(255) DEFAULT NULL,
  `extendFieldString` varchar(500) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(500) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(500) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `cablegroup` VALUES ('1', 'Cable Resources', '������Դ', '', '', '', '', '', '', '','', '', '', '', '', '0', '', '0', '', '0');

-- ----------------------------
-- Records of cablegroup
-- ----------------------------

-- ----------------------------
-- Table structure for cable
-- ----------------------------
DROP TABLE IF EXISTS `cable`;
CREATE TABLE `cable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cableName` varchar(64) NOT NULL,
  `groupid` int(11) NOT NULL,
  `cableNumber` int(11) DEFAULT NULL,
  `reservedCode` varchar(64) DEFAULT NULL,
  `cableCode` varchar(64) DEFAULT NULL,
  `manufacturer` varchar(64) DEFAULT NULL,
  `distance` float(128,0) NOT NULL,
  `coreNumber` int(11) DEFAULT NULL,
  `cableDesc` varchar(255) DEFAULT NULL,
  `startPoint` int(11) NOT NULL,
  `endPoint` int(11) NOT NULL,
  `item` varchar(64) DEFAULT NULL,
  `createtime` timestamp NOT NULL DEFAULT '2011-01-01 08:00:00',
  `cableParam` varchar(255) DEFAULT NULL,
  `extendFieldString` varchar(500) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(500) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(500) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cable_groupid` (`groupid`),
  CONSTRAINT `fk_cable_groupid` FOREIGN KEY (`groupid`) REFERENCES `cablegroup` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of cable
-- ----------------------------

-- ----------------------------
-- Table structure for cablealarm
-- ----------------------------
DROP TABLE IF EXISTS `cablealarm`;
CREATE TABLE `cablealarm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nodename` varchar(64) NOT NULL,
  `nodeip` varchar(64) NOT NULL,
  `nodetype` varchar(20) NOT NULL,
  `cableid` int(11) NOT NULL,
  `cablename` varchar(64) DEFAULT NULL,
  `alarmtype` varchar(64) DEFAULT NULL,
  `alarmreason` varchar(255) DEFAULT NULL,
  `alarmlever` varchar(4) DEFAULT NULL,
  `alarmcontent` varchar(255) DEFAULT NULL,
  `alarmtime` timestamp NOT NULL DEFAULT '2011-01-01 08:00:00',
  `extendFieldString` varchar(500) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(500) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(500) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cablealarm_cableid` (cableid),
  CONSTRAINT `fk_cablealarm_cableid` FOREIGN KEY (`cableid`) REFERENCES `cable` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of cablealarm
-- ----------------------------

-- ----------------------------
-- Table structure for cablepoint
-- ----------------------------
DROP TABLE IF EXISTS `cablepoint`;
CREATE TABLE `cablepoint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pointName` varchar(64) NOT NULL,
  `pointDesc` varchar(255) DEFAULT NULL,
  `longitude` double(64,6) NOT NULL,
  `latitude` double(64,6) NOT NULL,
  `beforepointid` int(11) DEFAULT NULL,
  `nextpointid` int(11) DEFAULT NULL,
  `distance` double(64,2) NOT NULL,
  `imageFile` varchar(255) DEFAULT NULL,
  `cableid` int(11) NOT NULL,
  `cableName` varchar(64) DEFAULT NULL,
  `pointParam` varchar(255) DEFAULT NULL,
  `extendFieldString` varchar(500) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(500) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(500) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_cablepoint_cableid` (cableid),
  CONSTRAINT `fk_cablepoint_cableid` FOREIGN KEY (`cableid`) REFERENCES `cable` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of cablepoint
-- ----------------------------

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionsname` varchar(64) NOT NULL,
  `permissionsenname` varchar(64) NOT NULL,
  `permissionslevel` int(4) NOT NULL,
  `extendFieldString` varchar(500) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(500) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(500) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of permissions
-- ----------------------------

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `userchinaname` varchar(64) DEFAULT NULL,
  `createtime` timestamp NULL DEFAULT NULL,
  `updatedtime` timestamp NULL DEFAULT NULL,
  `isenablerecievermessage` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telephonenum` int(11) DEFAULT NULL,
  `userDesc` varchar(255) DEFAULT NULL,
  `extendFieldString` varchar(500) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(500) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(500) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of userinfo
-- ----------------------------

-- ----------------------------
-- Table structure for userlog
-- ----------------------------
DROP TABLE IF EXISTS `userlog`;
CREATE TABLE `userlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `operateTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `operateObject` varchar(255) NOT NULL,
  `operateAction` varchar(255) NOT NULL,
  `logDesc` varchar(255) DEFAULT NULL,
  `extendFieldString` varchar(500) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(500) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(500) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of userlog
-- ----------------------------

-- ----------------------------
-- Table structure for user_permissions
-- ----------------------------
DROP TABLE IF EXISTS `user_permissions`;
CREATE TABLE `user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `permissionsenid` int(11) DEFAULT NULL,
  `userid` int(11) DEFAULT NULL,
  `extendFieldString` varchar(255) DEFAULT NULL,
  `extendFieldLong` bigint(255) DEFAULT NULL,
  `extendFieldStringB` varchar(255) DEFAULT NULL,
  `extendFieldLongB` bigint(255) DEFAULT NULL,
  `extendFieldStringC` varchar(255) DEFAULT NULL,
  `extendFieldLongC` bigint(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of user_permissions
-- ----------------------------
